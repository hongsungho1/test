/* ================================================================= */
// 설치 npm 
// npm install node-telegram-bot-api
// npm install mongodb
/* ================================================================= */


/* ================================================================= */
// 사용 예시 
// var ret = require(oAPP.path.join(__dirname, 'js/telegram.js'));
//     ret.send(TY_IFDATA, CB);
//                     
// 
/* ================================================================= */


/* ================================================================= */
/* 내부 광역 변수
/* ================================================================= */
//let oAPP;
let QA = RegExp("/qa ", "gi");
let MY = RegExp("/my ", "gi");
let ME = RegExp("/me ", "gi");
let START = RegExp("/start ");

let TYPE_QA = {
    "TYPE"        :"",    //답변 유형
    "QUESTION"    :"",    //질문 Text       
    "ANSWER"      :"",    //답변 Text
    "T_FILE_INFO" :[],    //파일 ID  
    "CHAT_ID"     :"",    //등록 사용자 채팅 ID
    "IS_PRIVATE"  :false, //개인 사용 (질문/답변)
    "FIRST_NAME"  :"",    //등록 사용자 "성"
    "LAST_NAME"   :"",    //등록 사용자 "이름"
    "ISDEL"       :""     //삭제 지시자 "X"
};


/* ================================================================= */
/* 내부 펑션 
/* ================================================================= */

async function LFN_getFileInfo(URL) {

    return new Promise(async function(resolve, reject) {

        const response = await fetch(URL,{method: 'GET'});
        const data = await response.json();
        resolve(data);
    
    });
}



//답변저장 : 파일 
async function lfn_bot_document(msg, isPrivate){

    return new Promise(async function(resolve, reject) {

        var LS_QA = JSON.parse(JSON.stringify(TYPE_QA));

        //질문   
        LS_QA.QUESTION = msg.reply_to_message.text.replace(QA, '');
        LS_QA.QUESTION = LS_QA.QUESTION.replace(MY, '');
        LS_QA.QUESTION = LS_QA.QUESTION.replace(ME, '');  
    
        //답변에 대한 유형 코드 
        LS_QA.TYPE = "03";
    
        //답
        LS_QA.ANSWER   = "";

        //채팅 id 
        LS_QA.CHAT_ID  = msg.chat.id;
    
        //등록 사용자 "성 이름"
        LS_QA.FIRST_NAME = msg.chat.first_name;
        LS_QA.LAST_NAME  = msg.chat.last_name;

        //개인 사용여부 
        LS_QA.IS_PRIVATE = isPrivate;

  
        //첨부 문서
        LS_QA.T_FILE_INFO.push(msg.document);

        //MongoDB 저장 
        oAPP.MongoDBO.collection('BOT_Learning').insertMany([LS_QA], {}, async (err, res)=>{
            if (err) { resolve("E"); return; }

            await oAPP.BOT.sendMessage(msg.chat.id, "등록되었습니다^^");

            resolve("S");
            
        }); 
        
    });

}


//답변저장 : 사진 
async function lfn_bot_photo(msg, isPrivate){

    return new Promise( async function(resolve, reject) {

        var LS_QA = JSON.parse(JSON.stringify(TYPE_QA));

        //질문   
        LS_QA.QUESTION = msg.reply_to_message.text.replace(QA, '');
        LS_QA.QUESTION = LS_QA.QUESTION.replace(MY, '');
        LS_QA.QUESTION = LS_QA.QUESTION.replace(ME, '');  
    
        //답변에 대한 유형 코드 
        LS_QA.TYPE = "02";
    
        //답
        LS_QA.ANSWER   = "";

        //채팅 id 
        LS_QA.CHAT_ID  = msg.chat.id;
    
        //등록 사용자 "성 이름"
        LS_QA.FIRST_NAME = msg.chat.first_name;
        LS_QA.LAST_NAME  = msg.chat.last_name;

        //개인 사용여부 
        LS_QA.IS_PRIVATE = isPrivate;

        //사진 첨부 정보 
        LS_QA.T_FILE_INFO = msg.photo;

        //MongoDB 저장 
        oAPP.MongoDBO.collection('BOT_Learning').insertMany([LS_QA], {}, async (err, res)=>{
            if (err) { resolve("E"); return; }

            await oAPP.BOT.sendMessage(msg.chat.id, "등록되었습니다^^");

            resolve("S");
            
        }); 
 
    });

}


//답변저장 : 스티커 이모티콘 
async function lfn_bot_sticker(msg, isPrivate){

    return new Promise(async function(resolve, reject) {
        
        debugger;

        var LS_QA = JSON.parse(JSON.stringify(TYPE_QA));

        //질문   
        LS_QA.QUESTION = msg.reply_to_message.text.replace(QA, '');
        LS_QA.QUESTION = LS_QA.QUESTION.replace(MY, '');
        LS_QA.QUESTION = LS_QA.QUESTION.replace(ME, '');  
    
        //답변에 대한 유형 코드 
        LS_QA.TYPE = "04";
    
        //답
        LS_QA.ANSWER   = "";

        //채팅 id 
        LS_QA.CHAT_ID  = msg.chat.id;
    
        //등록 사용자 "성 이름"
        LS_QA.FIRST_NAME = msg.chat.first_name;
        LS_QA.LAST_NAME  = msg.chat.last_name;

        //개인 사용여부 
        LS_QA.IS_PRIVATE = isPrivate;

        //스티커 첨부
        LS_QA.T_FILE_INFO.push(msg.sticker);

        //MongoDB 저장 
        oAPP.MongoDBO.collection('BOT_Learning').insertMany([LS_QA], {}, async (err, res)=>{
            if (err) { resolve("E"); return; }

            await oAPP.BOT.sendMessage(msg.chat.id, "등록되었습니다^^");

            resolve("S");
            
        }); 
        
    });

}

//답변저장 : 음성 메시지 
async function lfn_bot_voice(msg, isPrivate){

    return new Promise( async function(resolve, reject) {

        debugger;
        var LS_QA = JSON.parse(JSON.stringify(TYPE_QA));

        //질문   
        LS_QA.QUESTION = msg.reply_to_message.text.replace(QA, '');
        LS_QA.QUESTION = LS_QA.QUESTION.replace(MY, '');
        LS_QA.QUESTION = LS_QA.QUESTION.replace(ME, '');  
    
        //답변에 대한 유형 코드 
        LS_QA.TYPE = "05";
    
        //답
        LS_QA.ANSWER   = "";

        //채팅 id 
        LS_QA.CHAT_ID  = msg.chat.id;
    
        //등록 사용자 "성 이름"
        LS_QA.FIRST_NAME = msg.chat.first_name;
        LS_QA.LAST_NAME  = msg.chat.last_name;

        //개인 사용여부 
        LS_QA.IS_PRIVATE = isPrivate;

        //음성 첨부
        LS_QA.T_FILE_INFO.push(msg.voice);

        //MongoDB 저장 
        oAPP.MongoDBO.collection('BOT_Learning').insertMany([LS_QA], {}, async (err, res)=>{
            if (err) { resolve("E"); return; }

            await oAPP.BOT.sendMessage(msg.chat.id, "등록되었습니다^^");

            resolve("S");
            
        }); 


    });

}

//답변저장 : 일반 텍스트 
async function lfn_bot_text(msg, isPrivate){

    return new Promise( async function(resolve, reject) {

        var LS_QA = JSON.parse(JSON.stringify(TYPE_QA));

        //질문   
        LS_QA.QUESTION = msg.reply_to_message.text.replace(QA, '');
        LS_QA.QUESTION = LS_QA.QUESTION.replace(MY, '');
        LS_QA.QUESTION = LS_QA.QUESTION.replace(ME, '');  
    
        //답변에 대한 유형 코드 
        LS_QA.TYPE = "01";
    
        //답
        LS_QA.ANSWER   = msg.text;

        //채팅 id 
        LS_QA.CHAT_ID  = msg.chat.id;
    
        //등록 사용자 "성 이름"
        LS_QA.FIRST_NAME = msg.chat.first_name;
        LS_QA.LAST_NAME  = msg.chat.last_name;

        //개인 사용여부 
        LS_QA.IS_PRIVATE = isPrivate;


        //저장 
        oAPP.MongoDBO.collection('BOT_Learning').insertMany([LS_QA], {}, async (err, res)=>{
                if (err) { resolve("E"); return; }
    
                await oAPP.BOT.sendMessage(msg.chat.id, "👍 등록되었습니다");

                resolve("S");
                
        }); 
 
    });
    
}



/* ================================================================= */
/* Export Module Function 
/* ================================================================= */
exports.BOT_Learning = async function(msg) {

    return new Promise( async function(resolve, reject) {

        if(typeof msg === "undefined"){ resolve(false); return; }
        if(typeof msg !== "object"){ resolve(false); return; }

        //만일 봇 학습 시작 keyword 값이 존재한다면..
        if( typeof msg.entities !== "undefined" ){  

            if( ( msg.entities.length != 0 ) && msg.entities[0].type == "bot_command"){

                var LkeyWord = msg.text;
                    LkeyWord = LkeyWord.toLowerCase();

                //전체사용자가 볼수있는 질문 답에 대한 학습여부 ?
                if(LkeyWord.search(QA) == 0){
                    resolve(true); return; //현재 프로세스에서 종료 
                    
                }

                // private(개인) 질문 답에 대한 학습여부 ?
                if(LkeyWord.search(MY) == 0 || LkeyWord.search(ME) == 0){
                    resolve(true); return; //현재 프로세스에서 종료 
                }

                if(typeof msg.reply_to_message !== "undefined"){  resolve(true); return; }

                resolve(false); return;
            
            }

        }

        //만일 봇 학습 질문에 대한  값이 존재한다면..
        if(typeof msg.reply_to_message !== "undefined"){  

            if(typeof msg.reply_to_message.entities !== "undefined"){  

                if( ( msg.reply_to_message.entities.length != 0 ) && msg.reply_to_message.entities[0].type == "bot_command"){

                    //msg.reply_to_message.text <-- 이내용은 봇 질문 keyword 임
                    
                    var LkeyWord = msg.reply_to_message.text;
                        LkeyWord = LkeyWord.toLowerCase();

                    //전체사용자가 볼수있는 질문 답에 대한 학습여부 ?
                    if(LkeyWord.search(QA) == 0 ){

                        //질문답에 대한 처리 유형별 처리 

                            //파일 
                            if(typeof msg.document !== "undefined"){ await lfn_bot_document(msg, false); resolve(true); return; }

                            //사진 
                            if(typeof msg.photo    !== "undefined"){ await lfn_bot_photo(msg, false);    resolve(true); return; }

                            //스티커 이모티콘 
                            if(typeof msg.sticker  !== "undefined"){ await lfn_bot_sticker(msg, false);  resolve(true); return; }

                            //음성 메시지 
                            if(typeof msg.voice    !== "undefined"){ await lfn_bot_voice(msg, false);    resolve(true); return; }

                            //일반 텍스트 
                            if(typeof msg.text     !== "undefined"){ await lfn_bot_text(msg, false);     resolve(true); return;}

                            resolve(false); return;
                        
                    }


                    //private(개인) 질문 답에 대한 학습여부 ?
                    if(LkeyWord.search(MY) == 0 || LkeyWord.search(ME) == 0){

                        //질문답에 대한 처리 유형별 처리 

                            //파일 
                            if(typeof msg.document !== "undefined"){ await lfn_bot_document(msg, true); resolve(true); return; }

                            //사진 
                            if(typeof msg.photo    !== "undefined"){ await lfn_bot_photo(msg, true);   resolve(true); return; }

                            //스티커 이모티콘 
                            if(typeof msg.sticker  !== "undefined"){ await lfn_bot_sticker(msg, true);  resolve(true); return; }

                            //음성 메시지 
                            if(typeof msg.voice    !== "undefined"){ await lfn_bot_voice(msg, true);    resolve(true); return; }

                            //일반 텍스트 
                            if(typeof msg.text     !== "undefined"){ await lfn_bot_text(msg, true);     resolve(true); return; }

                            resolve(false); return;
                              
                    }

                }

            }

        }


        //만일 상위 프로세스 -> 봇 학습이 아닐 경우 답변글에 대해서는 지원않함 !!
        if(typeof msg.reply_to_message !== "undefined"){  resolve(true);  return; }
        if(typeof msg.reply_to_message === "undefined"){  resolve(false); return; }


    });

};