exports.createServer = function(remote, cb_req, cb_success, cb_error){



};

// Module.FACE  = ()=>{


//   $.getScript( "https://connect.facebook.net/en_US/sdk.js", function( data, textStatus, jqxhr ) {
//     debugger;  

//        FB.ini



//   });




// }






// var maximum = visualViewport.scale;


// function gfn_test(){
    
// var cc = "width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes";

// document.getElementsByName("viewport")[0].setAttribute("content", cc);

// sap.m.MessageToast.show(document.body.offsetHeight);


    
    
    
// }


// $(window).on("orientationchange",function(){
 
//  sap.m.MessageToast.show("land : " + maximum);
//     var ccc = "width=device-width, initial-scale=1.0, maximum-scale=" + maximum + ", user-scalable=yes";
//     document.getElementsByName("viewport")[0].setAttribute("content", ccc);
 
//          setTimeout(function() { 
             
//                  var ccc = "width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes";
//             document.getElementsByName("viewport")[0].setAttribute("content", ccc);
             
//          }, 100);
 
// });




// function viewportHandler() {
    
//     maximum = visualViewport.scale;
    
//     //sap.m.MessageToast.show(maximum);
    
//     return;
    
//     var ccc = "width=device-width, initial-scale=1.0, maximum-scale=" + visualViewport.scale + ", user-scalable=yes";
//     document.getElementsByName("viewport")[0].setAttribute("content", cc);



// }

// window.visualViewport.addEventListener('resize', viewportHandler);




/*

let prevVisualViewport = 0

function handleVisualViewportResize() { 
    
    INPUT1.setValue(window.visualViewport.scale);
    var aaa = document.getElementsByTagName("body");
    aaa[0].style.scale = "1";
    aaa[0].style.zoom = "1";
    return;
    
  const currentVisualViewport = window.visualViewport.height

  if (
    prevVisualViewport - 30 > currentVisualViewport &&
    prevVisualViewport - 100 < currentVisualViewport
  ) {
    const scrollHeight = window.document.scrollingElement.scrollHeight
    const scrollTop = scrollHeight - window.visualViewport.height

    window.scrollTo(0, scrollTop) // 입력창이 키보드에 가려지지 않도록 조절
  }

  prevVisualViewport = window.visualViewport.height
}

window.visualViewport.onresize = handleVisualViewportResize  

*/