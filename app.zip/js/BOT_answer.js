/* ================================================================= */
// 설치 npm 
// npm install node-telegram-bot-api
// npm install mongodb
/* ================================================================= */


/* ================================================================= */
// 사용 예시 
// var ret = require(oAPP.path.join(__dirname, 'js/telegram.js'));
//     ret.send(TY_IFDATA, CB);
//                     
// 
/* ================================================================= */


/* ================================================================= */
/* 내부 광역 변수
/* ================================================================= */
//let oAPP;
let QA = RegExp("/qa ", "gi");
let MY = RegExp("/my ", "gi");
let ME = RegExp("/me ", "gi");
let START = RegExp("/start");

let TYPE_QA = {
    "TYPE"        :"",    //답변 유형
    "QUESTION"    :"",    //질문 Text       
    "ANSWER"      :"",    //답변 Text
    "T_FILE_INFO" :[],    //파일 ID  
    "CHAT_ID"     :"",    //등록 사용자 채팅 ID
    "IS_PRIVATE"  :false, //개인 사용 (질문/답변)
    "FIRST_NAME"  :"",    //등록 사용자 "성"
    "LAST_NAME"   :"",    //등록 사용자 "이름"
    "ISDEL"       :""     //삭제 지시자 "X"
};

/* ================================================================= */
/* 내부 펑션 
/* ================================================================= */

async function LFN_getFileInfo(URL) {

    return new Promise(async function(resolve, reject) {

        const response = await fetch(URL,{method: 'GET'});
        const data = await response.json();
        resolve(data);
    
    });
}


//일반 텍스트로 답변 
async function LFN_answer01(msg, sDBdata, resolve) {
    // msg     : telegram API 에서 넘어온 message 오브젝트
    // sDBdata : 몽고 DB에 등록된 Data 
    // 프로미스 return 호출 처리 오브젝트 

    await oAPP.BOT.sendMessage(msg.chat.id, sDBdata.ANSWER);
    resolve(true);

} 


//이미지 답변 
async function LFN_answer02(msg, sDBdata, resolve) {
    // msg     : telegram API 에서 넘어온 message 오브젝트
    // sDBdata : 몽고 DB에 등록된 Data 
    // 프로미스 return 호출 처리 오브젝트 

    for (let i = 0; i < sDBdata.T_FILE_INFO.length; i++) {
        var sLine = sDBdata.T_FILE_INFO[i];
        await oAPP.BOT.sendPhoto(msg.chat.id, sLine.file_id);
        break;

    }

    resolve(true);

} 


//첨부파일 답변 
async function LFN_answer03(msg, sDBdata, resolve) {
    // msg     : telegram API 에서 넘어온 message 오브젝트
    // sDBdata : 몽고 DB에 등록된 Data 
    // 프로미스 return 호출 처리 오브젝트 

    for (let i = 0; i < sDBdata.T_FILE_INFO.length; i++) {
        var sLine = sDBdata.T_FILE_INFO[i];
        await oAPP.BOT.sendDocument(msg.chat.id, sLine.file_id);
        break;  
    }


    resolve(true);

} 

//스티커 이모티콘 텍스트로 답변 
async function LFN_answer04(msg, sDBdata, resolve) {
    // msg     : telegram API 에서 넘어온 message 오브젝트
    // sDBdata : 몽고 DB에 등록된 Data 
    // 프로미스 return 호출 처리 오브젝트 

    for (let i = 0; i < sDBdata.T_FILE_INFO.length; i++) {
        var sLine = sDBdata.T_FILE_INFO[i];
        await oAPP.BOT.sendSticker(msg.chat.id, sLine.file_id);
        break;

    }

    resolve(true);

} 

//음성 답변 
async function LFN_answer05(msg, sDBdata, resolve) {
    // msg     : telegram API 에서 넘어온 message 오브젝트
    // sDBdata : 몽고 DB에 등록된 Data 
    // 프로미스 return 호출 처리 오브젝트 

    for (let i = 0; i < sDBdata.T_FILE_INFO.length; i++) {
        var sLine = sDBdata.T_FILE_INFO[i];
        await oAPP.BOT.sendAudio(msg.chat.id, sLine.file_id);
        
    }

    resolve(true);

} 





/* ================================================================= */
/* Export Module Function 
/* ================================================================= */
exports.BOT_answer = async function(msg) {

    return new Promise( async function(resolve, reject) {

        debugger;

        if(typeof msg === "undefined"){ resolve(false); return; }
        if(typeof msg !== "object"){ resolve(false); return; }
        if(typeof msg.text === "undefined"){ resolve(false); return; }

        if(msg.text.search(START) == 0 ){ 

            var Lmsg = msg.chat.first_name + " " + msg.chat.last_name + " 님" + " \n " + "환영합니다^^";
            await oAPP.BOT.sendMessage(msg.chat.id, Lmsg);
            resolve(true); return;  
        }
        
    
        //[본인만 해당] 기 등록된(MogoDB) 정보로 현재 사용자 입력값으로 값 추출 
        //var query = { $and:[{"QUESTION":{'$regex': msg.text}}, {"IS_PRIVATE":true}]};

        var T_result = [];

        function get_data(step){

            switch (step) {
                case "01": //내가 등록한건만
                    var query = { $and:[{"QUESTION":{'$regex': msg.text, '$options': 'i'}}, {"CHAT_ID":msg.chat.id} ,{"IS_PRIVATE":true}]};
                    break;
            
                default:  // 전체적으로 등록한건 
                    var query = { $and:[{"QUESTION":{'$regex': msg.text, '$options': 'i'}}, {"IS_PRIVATE":false}]};
                    break;
            }
            
            oAPP.MongoDBO.collection("BOT_Learning").find(query).limit(10).toArray(function(err, result) {

                //크리티컬 오류(DB 연결 오류)
                if (typeof err !== "undefined") { 
                     resolve(false); return;
                }

                if (result.length == 0 && T_result.length == 0 ) {  

                    if(step == "02"){ resolve(false); return; }

                    get_data("02");
                    return; 

                };

                //검색 결과 전역변수 할당
                for (var i = 0; i < result.length; i++) { 
                    var S_result = result[i]; 

                    if(step == "01"){
                        S_result.ANSWER = "♥ " + S_result.ANSWER;

                    }

                    T_result.push(S_result); 
                }
        
                if(step == "01"){ get_data("02"); return; }

                for (var i = 0; i < T_result.length; i++) {
                    var sDBdata = T_result[i];
                    
                    switch (sDBdata.TYPE) {
                        case "01": //일반텍스트 답변
                            LFN_answer01(msg, sDBdata, resolve);  
                            break;
                    
                        case "02": //이미지 답변
                            LFN_answer02(msg, sDBdata, resolve);   
                            break;
    
                        case "03": //첨부파일 답변 
                            LFN_answer03(msg, sDBdata, resolve);  
                            break;
    
                        case "04": //첨부파일 답변 
                            LFN_answer04(msg, sDBdata, resolve);  
                            break;
    
                        case "05": //음성 답변 
                            LFN_answer05(msg, sDBdata, resolve);    
                            break;
    
                        default:
                            resolve(false); return;
                            break;
                    }
    
                }

            });    

        }

        get_data("01");

        /*
        oAPP.MongoDBO.collection("BOT_Learning").find(query).limit(10).toArray(function(err, result) {
          
            if (err) { resolve(false); return; };

            //검색 정보가 누락이라면 ..
            if(result.length === 0){ resolve(false); return; }

            for (let i = 0; i < result.length; i++) {
                var sDBdata = result[i];
                
                switch (sDBdata.TYPE) {
                    case "01": //일반텍스트 답변
                        LFN_answer01(msg, sDBdata, resolve);  
                        break;
                
                    case "02": //이미지 답변
                        LFN_answer02(msg, sDBdata, resolve);   
                        break;

                    case "03": //첨부파일 답변 
                        LFN_answer03(msg, sDBdata, resolve);  
                        break;

                    case "04": //첨부파일 답변 
                        LFN_answer04(msg, sDBdata, resolve);  
                        break;

                    case "05": //음성 답변 
                        LFN_answer05(msg, sDBdata, resolve);    
                        break;

                    default:
                        resolve(false); return;
                        break;
                }

            }

        });
        */

    });

};