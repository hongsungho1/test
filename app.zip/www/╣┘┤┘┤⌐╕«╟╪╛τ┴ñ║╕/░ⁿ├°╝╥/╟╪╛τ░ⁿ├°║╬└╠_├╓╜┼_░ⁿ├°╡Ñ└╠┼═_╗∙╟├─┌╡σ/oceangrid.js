        var map;
        var loadEnd;
        var oloMarker; // OpenLayer Overview Marker
		var obslonlat = {
			TW_0089:{lon:128.932,lat:37.80884},
			TW_0079:{lon:126.1943,lat:35.65246},
			TW_0080:{lon:125.8003,lat:34.54414},
			TW_0081:{lon:126.9603,lat:34.25872},
			TW_0062:{lon:129.1697,lat:35.14889},
			HB_0001:{lon:129.2353,lat:35.18244},
			HB_0002:{lon:129.3147,lat:35.3185},
			HB_0003:{lon:129.3681,lat:35.38472},
			HB_0004:{lon:129.495,lat:35.63472},
			HB_0005:{lon:129.495,lat:35.71778},
			HB_0006:{lon:129.5472,lat:35.86583},
			TW_0072:{lon:126.5089,lat:35.98361},
			TW_0070:{lon:126.5408,lat:37.1367},
			TW_0069:{lon:126.4553,lat:36.27972},
			TW_0083:{lon:127.8081,lat:34.79472},
			TW_0084:{lon:128.46,lat:34.77333},
			TW_0078:{lon:126.7633,lat:34.325},
			TW_0087:{lon:129.0853,lat:35.09175},
			TW_0086:{lon:128.7618,lat:35.04378},
			TW_0077:{lon:126.5922,lat:37.52333},
			TW_0074:{lon:127.7928,lat:34.85972},
			TW_0082:{lon:126.2702,lat:37.00672},
			TW_0088:{lon:129.0031,lat:35.05281},
			TW_0075:{lon:126.4097,lat:33.23444},
			TW_0076:{lon:126.5331,lat:37.38944},
			TW_0085:{lon:128.6318,lat:35.10319},
			KG_0021:{lon:126.9659,lat:32.09042},
			KG_0024:{lon:129.1213,lat:34.919},
			KG_0025:{lon:128.419,lat:34.22247},
			KG_0028:{lon:126.4921,lat:33.91181},
			KG_0101:{lon:131.5526,lat:38.00736},
			KG_0102:{lon:130.6012,lat:37.74272},
			RD_0003:{lon:129.3819,lat:35.44333}
		};

        function init() {
            map = new OpenLayers.Map('map', {
			  theme: null,
			  controls: [
				  new OpenLayers.Control.Attribution(),
				  new OpenLayers.Control.Navigation({
					  dragPanOptions: {
						  enableKinetic: true
					  }
				  })
			  ],
			  sphericalMercator: true,
			  projection: new OpenLayers.Projection("EPSG:900913"),
			  units: "m",
			  numZoomLevels: 16,
			  maxResolution: 156543.0339,
			  maxExtent: new OpenLayers.Bounds(-20037508.34, -20037508.34, 20037508.34, 20037508.34),
			  restrictedExtent: new OpenLayers.Bounds(12823060.932019735,3248973.789650974, 15730006.674231393,5621521.486192066),
			  isValidZoomLevel : function(zoomLevel) {
							return ((zoomLevel != null) && (zoomLevel >= 6) && (zoomLevel < 16));
						}
			});

            

              var vWorldStreet = new OpenLayers.Layer.XYZ(
                "VWorld Street Map",
                [
					"http://xdworld.vworld.kr:8080/2d/Base/201512/${z}/${x}/${y}.png"
                ]
            );
            
			map.addLayers([vWorldStreet]);
			map.setCenter(new OpenLayers.LonLat(14243425.793355, 4302305.8698004), 7); // Zoom level
									
			var og_gd01_as = new OpenLayers.Layer.WMS(
					'og_gd01_as', 'http://www.khoa.go.kr/oceangrid/cmm/proxyRun.do?call=wms',
					{
						layers: 'geotwo_postgis:og_gd01_as', transparent: 'true' 
 						,version: '1.1.0'
					}, {
                        singleTile: true
					}
				)			
			map.addLayers([og_gd01_as]);


	}//init end




 function setMarker(map,lon,lat){
	if(map.getLayersByName("markername").length != 0){
		map.removeLayer(map.getLayersByName("markername")[0]);
	}

	for(idx =0; idx < map.popups.length;idx++){
			map.removePopup(map.popups[idx]);
		}
 
	var lon_lat = new OpenLayers.Geometry.Point(lon,lat).transform(new OpenLayers.Projection("EPSG:4326"),map.projection);
	var overlay = new OpenLayers.Layer.Vector("markername", {
			styleMap: new OpenLayers.StyleMap({
				externalGraphic: 'img/icon_DT_v01.png',
				graphicWidth: 20, graphicHeight: 24, graphicYOffset: -24,
				title: ''
			})
		});

    overlay.addFeatures([
        new OpenLayers.Feature.Vector(lon_lat, {tooltip: 'OpenLayers'})
    ]);

	map.addLayers([overlay]);

 }
	
	
	
	function createMetaPopup(ObsCode,data,ResultType){
		for(idx =0; idx < map.popups.length;idx++){
			map.removePopup(map.popups[idx]);
		}

		var lon = eval("obslonlat."+ObsCode).lon;
		var lat = eval("obslonlat."+ObsCode).lat;
		var content ="";
		if(data.result.data != undefined){
			if(ResultType == "json"){
				content = "<table id='metaList' name='metaList' style='font-size:.7em' >";
				content += "<tr><th>고정 관측소 ID</th><td>" + data.result.meta.obs_post_id + "</td></tr>";
				content += "<tr><th>고정 관측소 명</th><td>" + data.result.meta.obs_post_name + "</td></tr>";
				content += "<tr><th>고정 관측소 위도</th><td>" + data.result.meta.obs_lat + "</td></tr>";
				content += "<tr><th>고정 관측소 경도</th><td>" + data.result.meta.obs_lon + "</td></tr>";
				content += "<tr><th>금일요청가능횟수</th><td>" + data.result.meta.obs_last_req_cnt + "</td></tr>";
				content += "<tr><th>관측시간</th><td>" + data.result.data.record_time + "</td></tr>";
				content += "<tr><th>풍속</th><td>" + data.result.data.wind_speed + "</td></tr>";
				content += "<tr><th>풍향</th><td>" + data.result.data.wind_dir + "</td></tr>";
				content += "<tr><th>기온</th><td>" + data.result.data.air_temp + "</td></tr>";
				content += "<tr><th>기압</th><td>" + data.result.data.air_pres + "</td></tr>";
				content += "<tr><th>수온</th><td>" + data.result.data.water_temp + "</td></tr>";
				content += "<tr><th>염분</th><td>" + data.result.data.Salinity + "</td></tr>";
				content += "<tr><th>유속</th><td>" + data.result.data.current_speed + "</td></tr>";
				content += "<tr><th>유향</th><td>" + data.result.data.current_dir + "</td></tr>"; 
				content += "</table>"; 	
			}else if(ResultType == "xml"){
				content = "<table id='metaList' name='metaList'  style='font-size:.7em'>";
				content += "<tr><th>고정 관측소 ID</th><td>" + $(data).find("result").find("meta").find("obs_post_id").text() + "</td></tr>";
				content += "<tr><th>고정 관측소 명</th><td>" + $(data).find("result").find("meta").find("obs_post_name").text() + "</td></tr>";
				content += "<tr><th>고정 관측소 위도</th><td>" + $(data).find("result").find("meta").find("obs_lat").text() + "</td></tr>";
				content += "<tr><th>고정 관측소 경도</th><td>" + $(data).find("result").find("meta").find("obs_lon").text() + "</td></tr>";
				content += "<tr><th>금일요청가능횟수</th><td>" + $(data).find("result").find("meta").find("obs_last_req_cnt").text() + "</td></tr>";
				content += "<tr><th>관측시간</th><td>" + $(data).find("result").find("data").find("record_time").text() + "</td></tr>";
				content += "<tr><th>풍속</th><td>" + $(data).find("result").find("data").find("wind_speed").text() + "</td></tr>";
				content += "<tr><th>풍향</th><td>" + $(data).find("result").find("data").find("wind_dir").text() + "</td></tr>";
				content += "<tr><th>기온</th><td>" + $(data).find("result").find("data").find("air_temp").text() + "</td></tr>";
				content += "<tr><th>기압</th><td>" + $(data).find("result").find("data").find("air_pres").text() + "</td></tr>";
				content += "<tr><th>수온</th><td>" + $(data).find("result").find("data").find("water_temp").text() + "</td></tr>";
				content += "<tr><th>염분</th><td>" + $(data).find("result").find("data").find("Salinity").text() + "</td></tr>";
				content += "<tr><th>유속</th><td>" + $(data).find("result").find("data").find("current_speed").text() + "</td></tr>";
				content += "<tr><th>유향</th><td>" + $(data).find("result").find("data").find("current_dir").text() + "</td></tr>";
				content += "</table>";
			}
			var popup = new OpenLayers.Popup.FramedCloud(ObsCode, 
				new OpenLayers.Geometry.Point(lon,lat).transform(new OpenLayers.Projection("EPSG:4326"),map.projection).getBounds().getCenterLonLat(), null
				,content
				,null
				,false 
			);
			map.addPopup(popup);
		}else{
			alert("검색된 데이터가 없습니다.");
		}
	}