$(function(){

		$('.schbtn').on('click', function() {	
			if($("#openTop").attr("alt") == "닫기"){
				hideSearchDiv();
			}else{
				showSearchDiv();
			}
		});

		$('#obsCode').on('change', function() {	
			setMarker(map,eval("obslonlat."+this.value).lon,eval("obslonlat."+this.value).lat)
		});
		
		$( "#progressbar" ).progressbar({ value: false});
});

var animateState = false;
var callback = function(){
	animateState = true;
};

var keepOffsetOn = function(obj){
	var offset = $(obj).offset();
	$(obj).css("left",offset.left+"px");
	$(obj).css("right","auto");
}

var keepOffsetOff = function(obj){
	var width = $(obj).outerWidth()-20;
	$(obj).css("right","-"+width+"px");
	$(obj).css("left","auto");
}


var showSearchDiv = function(){
		var height = $("#searchKeyTop").outerHeight();	
		$(".stop" ).animate({"top": "+="+height+"px" }, "slow" );
		$("#openTop").attr("alt","닫기");
		$("#openTop").attr("src","img/btn_top_c.png");
	};	
var hideSearchDiv = function(){
		var height = $("#searchKeyTop").outerHeight();
		$(".stop" ).animate({"top": "-="+height+"px" }, "slow" );
		$("#openTop").attr("alt","열기");
		$("#openTop").attr("src","img/btn_top_o.png");
	};