var map;
var loadEnd;
var oloMarker; // OpenLayer Overview Marker
		
		
function init() {
	map = new OpenLayers.Map('map', {
	  theme: null,
	  controls: [
		  new OpenLayers.Control.Attribution(),
		  new OpenLayers.Control.Navigation({
			  dragPanOptions: {
				  enableKinetic: true
			  }
		  })
	  ],
	  sphericalMercator: true,
	  projection: new OpenLayers.Projection("EPSG:900913"),
	  units: "m",
	  numZoomLevels: 16,
	  maxResolution: 156543.0339,
	  maxExtent: new OpenLayers.Bounds(-20037508.34, -20037508.34, 20037508.34, 20037508.34),
	  restrictedExtent: new OpenLayers.Bounds(12823060.932019735,3248973.789650974, 15730006.674231393,5621521.486192066),
	  isValidZoomLevel : function(zoomLevel) {
					return ((zoomLevel != null) && (zoomLevel >= 6) && (zoomLevel < 16));
				}
	});

            

var vWorldStreet = new OpenLayers.Layer.XYZ(
	"VWorld Street Map",
	[
		"http://xdworld.vworld.kr:8080/2d/Base/201512/${z}/${x}/${y}.png"
	]
);

map.addLayers([vWorldStreet]);
map.setCenter(new OpenLayers.LonLat(14243425.793355, 4302305.8698004), 7); // Zoom level
						
var og_gd01_as = new OpenLayers.Layer.WMS(
		'og_gd01_as', 'http://www.khoa.go.kr/oceangrid/cmm/proxyRun.do?call=wms',
		{
			layers: 'geotwo_postgis:og_gd01_as', transparent: 'true' 
			,version: '1.1.0'
		}, {
			singleTile: true
		}
	)
		map.addLayers([og_gd01_as]);	


}//init end




	function removeObsMarker(){
		var removeCnt = map.getLayersBy("secendName","obsMarker").length; 
		if(removeCnt > 0){
			var removeArry =map.getLayersBy("secendName","obsMarker") ; 
			for( idx = 0; idx < removeCnt; idx++){
				map.removeLayer(removeArry[idx]);
			}
		}
	}

 function setMarker(lon,lat,name){
	var lon_lat = new OpenLayers.Geometry.Point(lon,lat).transform(new OpenLayers.Projection("EPSG:4326"),map.projection);
	var overlay = new OpenLayers.Layer.Vector(name, {secendName:"obsMarker",
			styleMap: new OpenLayers.StyleMap({
				externalGraphic: 'img/icon_DT_v01.png',
				graphicWidth: 20,
				graphicHeight: 24,
				graphicYOffset: -24,
				title: ''
			})
		});

    overlay.addFeatures([
        new OpenLayers.Feature.Vector(lon_lat, {tooltip: 'OpenLayers'})
    ]);

	map.addLayers([overlay]);
	
	
 }
	
	function keepOffsetOn(obj){
		var asd = $(obj).offset();
		$(obj).css("left",asd.left+"px");
		$(obj).css("right","auto");
	}

	function keepOffsetOff(obj){
		var width = $(obj).outerWidth()-20;
		$(obj).css("right","-"+width+"px");
		$(obj).css("left","auto");
	}
 
	
	function jsonparser(data){
		$("#dataList").find("tr").remove();
		removeObsMarker();
		if(data.result.data == undefined){
			$("#dataList").append( "<tr><td>검새된 데이터가 없습니다.</td></tr>" );
			return false;
		}else{
			var datalist = data.result.data;
			$("#dataList").append("<tr><th colspan =2 >금일요청가능횟수</th><td colspan=4>" + data.result.meta.obs_last_req_cnt + "</td></tr>");
			$("#dataList").append("<tr><td colspan =6 style='border-left:none;border-right:none;'></td></tr>");
			$("#dataList").append("<tr><th >고정 관측소 ID</th><th>고정 관측소 유형</th><th>고정관측소 이름</th><th>위도</th><th>경도</th><th>서비스항목</th></tr>"); 
			for(var i=0; i< data.result.data.length; i++){
				var obs_post_id =datalist[i].obs_post_id; 
				var data_type =datalist[i].data_type;
				var obs_post_name =datalist[i].obs_post_name; 
				var obs_lat =datalist[i].obs_lat;
				var obs_lon =datalist[i].obs_lon; 
				var obs_object =datalist[i].obs_object;
				setMarker(obs_lon,obs_lat,obs_post_id);
				 $("#dataList").append( "<tr id='"+obs_post_id+"'><td>"+obs_post_id+"</td><td>"+data_type+"</td><td>"+obs_post_name+"</td><td>"+obs_lat+"</td><td>"+obs_lon+"</td><td>"+obs_object+"</td></tr>" ); 
			}

			$("tr").mouseover(function(){
				var changeStyle = new OpenLayers.StyleMap({
					externalGraphic: 'img/marker.png',
					graphicWidth: 20,
					graphicHeight: 24,
					graphicYOffset: -24,
					title: ''
				});
				var marketLeyer = map.getLayersByName($(this).attr("id"))[0];
				var lonlat = marketLeyer.styleMap=changeStyle;
					map.removeLayer(marketLeyer);
					map.addLayers([marketLeyer]);
					//marketLeyer.redraw();
			});
			$("tr").mouseout(function(){
				var changeStyle = new OpenLayers.StyleMap({
					externalGraphic: 'img/icon_DT_v01.png',
					graphicWidth: 20,
					graphicHeight: 24,
					graphicYOffset: -24,
					title: ''
				});
				var marketLeyer = map.getLayersByName($(this).attr("id"))[0];
				var lonlat = marketLeyer.styleMap=changeStyle;
					marketLeyer.redraw();
			});
			return true;
		}
	}

	function xmlparser(data){
		if($(data).find("result") != ""){
			$("#dataList").find("tr").remove();
			removeObsMarker();
			var dataLength = $(data).find("result").find("data").length;
			if(dataLength <= 0){
				$("#dataList").append( "<tr><td>검색된 데이터가 없습니다.</td></tr>" ); 
				return false;
			}else{
                $("#dataList").append("<tr><th colspan =2 >금일요청가능횟수</th><td colspan=4>" + $(data).find("result").find("meta").find("obs_last_req_cnt").text() + "</td></tr>");
				$("#dataList").append("<tr><th colspan =6 style='border-left:none;border-right:none;'></td></tr>");
				$("#dataList").append("<tr><th >고정 관측소 ID</th><th>고정 관측소 유형</th><th>고정관측소 이름</th><th>위도</th><th>경도</th><th>서비스항목</th></tr>");  
				var idx = 1;
				$(data).find("result").find("data").each(function(){
					var obs_post_id = $(this).find("obs_post_id").text();
					var data_type = $(this).find("data_type").text();
					var obs_post_name = $(this).find("obs_post_name").text();
					var obs_lat = $(this).find("obs_lat").text();
					var obs_lon = $(this).find("obs_lon").text();
					var obs_object = $(this).find("obs_object").text();
					setMarker(obs_lon,obs_lat,obs_post_id);
					 $("#dataList").append( "<tr id='"+obs_post_id+"'><td>"+obs_post_id+"</td><td>"+data_type+"</td><td>"+obs_post_name+"</td><td>"+obs_lat+"</td><td>"+obs_lon+"</td><td>"+obs_object+"</td></tr>" ); 
				});

				$("tr").mouseover(function(){
				
				var changeStyle = new OpenLayers.StyleMap({
					externalGraphic: 'img/marker.png',
					graphicWidth: 20,
					graphicHeight: 24,
					graphicYOffset: -24,
					title: ''
				});
				var marketLeyer = map.getLayersByName($(this).attr("id"))[0];
				var lonlat = marketLeyer.styleMap=changeStyle;
					map.removeLayer(marketLeyer);
					map.addLayers([marketLeyer]);
					//marketLeyer.redraw();
				});

			$("tr").mouseout(function(){
				var changeStyle = new OpenLayers.StyleMap({
					externalGraphic: 'img/icon_DT_v01.png',
					graphicWidth: 20,
					graphicHeight: 24,
					graphicYOffset: -24,
					title: ''
				});
				var marketLeyer = map.getLayersByName($(this).attr("id"))[0];
				var lonlat = marketLeyer.styleMap=changeStyle;
					marketLeyer.redraw();
			});
				return true;
			}
		}
	}