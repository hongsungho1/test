        var map;
        var loadEnd;
        var oloMarker; // OpenLayer Overview Marker
		var obslonlat = {
			DT_0001:{lat:37.45198,lon:126.592111},
			DT_0002:{lat:36.96686,lon:126.822694},
			DT_0003:{lat:35.42616,lon:126.420658},
			DT_0004:{lat:33.52748,lon:126.543169},
			DT_0005:{lat:35.09628,lon:129.0354},
			DT_0006:{lat:37.55036,lon:129.116317},
			DT_0007:{lat:34.77976,lon:126.375556},
			DT_0008:{lat:37.19215,lon:126.647228},
			DT_0009:{lat:36.04713,lon:129.383806},
			DT_0010:{lat:33.23995,lon:126.561644},
			DT_0011:{lat:36.67756,lon:129.453194},
			DT_0012:{lat:38.20709,lon:128.594083},
			DT_0013:{lat:37.4915,lon:130.913722},
			DT_0014:{lat:34.82768,lon:128.434703},
			DT_0015:{lat:35.21,lon:128.5889},
			DT_0016:{lat:34.74727,lon:127.7655306},
			DT_0017:{lat:37.0075,lon:126.3527778},
			DT_0018:{lat:35.97549,lon:126.563114},
			DT_0019:{lat:35.02418,lon:128.810933},
			DT_0020:{lat:35.50183,lon:129.387167},
			DT_0021:{lat:33.96183,lon:126.300139},
			DT_0022:{lat:33.47472,lon:126.927708},
			DT_0023:{lat:33.21433,lon:126.251169},
			DT_0024:{lat:36.00694,lon:126.6875},
			DT_0025:{lat:36.40639,lon:126.4861111},
			DT_0026:{lat:34.48112,lon:127.342656},
			DT_0027:{lat:34.31551,lon:126.759597},
			DT_0028:{lat:34.37769,lon:126.308572},
			DT_0029:{lat:34.80151,lon:128.699242},
			DT_0030:{lat:35.61806,lon:126.3016667},
			DT_0031:{lat:34.02843,lon:127.308886},
			DT_0032:{lat:37.73194,lon:126.5222222},
			DT_0034:{lat:36.67366,lon:126.132247},
			DT_0035:{lat:34.68417,lon:125.4355556},
			DT_0037:{lat:36.11729,lon:125.984783},
			DT_0038:{lat:37.19457,lon:125.995083},
			DT_0039:{lat:36.71903,lon:129.732361},
			DT_0041:{lat:34.09846,lon:126.168275},
			DT_0042:{lat:34.70472,lon:128.306389},
			DT_0043:{lat:37.23944,lon:126.4286111},
			DT_0044:{lat:37.5455,lon:126.584472},
			DT_0046:{lat:37.55616,lon:130.939211},
			DT_0047:{lat:33.15806,lon:126.2747222},
			DT_0048:{lat:38.19948,lon:128.613083},
			DT_0049:{lat:34.90367,lon:127.754836},
			DT_0050:{lat:36.91306,lon:126.2388889},
			DT_0051:{lat:36.12889,lon:126.4952778},
			DT_0052:{lat:37.33819,lon:126.5860417},
			DT_0054:{lat:35.14722,lon:128.643056},
			DT_0055:{lat:34.88111,lon:127.518611},
			DT_0056:{lat:35.0775,lon:128.7847222},
			DT_0057:{lat:37.49472,lon:129.1438889},
			DT_0058:{lat:37.56083,lon:126.6011111},
			DT_0061:{lat:34.92406,lon:128.069722},
			DT_0900:{lat:36.04694444,lon:129.3836111}
		};
		
        function init() {
             map = new OpenLayers.Map('map', {
			  theme: null,
			  controls: [
				  new OpenLayers.Control.Attribution(),
				  new OpenLayers.Control.Navigation({
					  dragPanOptions: {
						  enableKinetic: true
					  }
				  })
			  ],
			  sphericalMercator: true,
			  projection: new OpenLayers.Projection("EPSG:900913"),
			  units: "m",
			  numZoomLevels: 16,
			  maxResolution: 156543.0339,
			  maxExtent: new OpenLayers.Bounds(-20037508.34, -20037508.34, 20037508.34, 20037508.34),
			  restrictedExtent: new OpenLayers.Bounds(12823060.932019735,3248973.789650974, 15730006.674231393,5621521.486192066),
			  isValidZoomLevel : function(zoomLevel) {
							return ((zoomLevel != null) && (zoomLevel >= 6) && (zoomLevel < 16));
						}
			});

            

           var vWorldStreet = new OpenLayers.Layer.XYZ(
                "VWorld Street Map",
                [
					"http://xdworld.vworld.kr:8080/2d/Base/201512/${z}/${x}/${y}.png"
                ]
            );
            
			map.addLayers([vWorldStreet]);
			map.setCenter(new OpenLayers.LonLat(14243425.793355, 4302305.8698004), 7); // Zoom level
									
			var og_gd01_as = new OpenLayers.Layer.WMS(
					'og_gd01_as', 'http://www.khoa.go.kr/oceangrid/cmm/proxyRun.do?call=wms',
					{
						layers: 'geotwo_postgis:og_gd01_as', transparent: 'true' 
 						,version: '1.1.0'
					}, {
                        singleTile: true
					}
				)			
			map.addLayers([og_gd01_as]);	


	}//init end




 function setMarker(map,lon,lat){
	if(map.getLayersByName("markername").length != 0){
		map.removeLayer(map.getLayersByName("markername")[0]);
	}
 
	var lon_lat = new OpenLayers.Geometry.Point(lon,lat).transform(new OpenLayers.Projection("EPSG:4326"),map.projection);
	var overlay = new OpenLayers.Layer.Vector("markername", {
			styleMap: new OpenLayers.StyleMap({
				externalGraphic: 'img/icon_DT_v01.png',
				graphicWidth: 20, graphicHeight: 24, graphicYOffset: -24,
				title: ''
			})
		});

    overlay.addFeatures([
        new OpenLayers.Feature.Vector(lon_lat, {tooltip: 'OpenLayers'})
    ]);

	map.addLayers([overlay]);

 }
	
	function keepOffsetOn(obj){
		var asd = $(obj).offset();
		$(obj).css("left",asd.left+"px");
		$(obj).css("right","auto");
	}

	function keepOffsetOff(obj){
		var width = $(obj).outerWidth()-20;
		$(obj).css("right","-"+width+"px");
		$(obj).css("left","auto");
	}
 
	
	function jsonparser(data){
		$("#dataList").find("tr").remove();
		if(data.result.data == undefined){
			$("#dataList").append( "<tr><td>검새된 데이터가 없습니다.</td></tr>" );
			return false;
		}else{
			var datalist = data.result.data;
			$("#dataList").append( "<tr><th>관측시간</th><th>조위</th></tr>" ); 
			for(var i=0; i< data.result.data.length; i++){
				var tide_level =datalist[i].tide_level; 
				var record_time =datalist[i].record_time;
				 $("#dataList").append( "<tr><td>"+record_time+"</td><td>"+tide_level+"</td></tr>" ); 
			}
			return true;
		}
	}

	function xmlparser(data){
		if($(data).find("result") != ""){
			$("#dataList").find("tr").remove();
			var dataLength = $(data).find("result").find("data").length;
			if(dataLength <= 0){
				$("#dataList").append( "<tr><td>검새된 데이터가 없습니다.</td></tr>" ); 
				return false;
			}else{
				$("#dataList").append( "<tr><th>관측시간</th><th>조위</th></tr>" ); 
				var idx = 1;
				$(data).find("result").find("data").each(function(){
					 $("#dataList").append( "<tr><td>"+$(this).find("record_time").text()+"</td><td>"+$(this).find("tide_level").text()+"</td></tr>" ); 
				});
				return true;
			}
		}
	}

	
	function createMetaPopup(ObsCode,data,ResultType){
		for(idx =0; idx < map.popups.length;idx++){
			map.removePopup(map.popups[idx]);
		}

		var lon = eval("obslonlat."+ObsCode).lon;
		var lat = eval("obslonlat."+ObsCode).lat;
		var content = "";
		if(ResultType == "json"){
			content = "<table id='metaList' name='metaList' style='font-size:11'>";
			content += "<tr><th>고정 관측소 ID</th><td>"+	data.result.meta.obs_post_id+"</td></tr>"; 
			content += "<tr><th>고정 관측소 명</th><td>"+data.result.meta.obs_post_name+"</td></tr>"; 
			content += "<tr><th>고정 관측소 위도</th><td>"+data.result.meta.obs_lat+"</td></tr>"; 
			content += "<tr><th>고정 관측소 경도</th><td>"+data.result.meta.obs_lon+"</td></tr>"; 
			content += "<tr><th>금일요청가능횟수</th><td>"+data.result.meta.obs_last_req_cnt+"</td></tr>"; 
			content += "</table>"; 	
		}else if(ResultType == "xml"){
			content = "<table id='metaList' name='metaList' style='font-size:11' >";
			content += "<tr><th>고정 관측소 ID</th><td>"+	$(data).find("result").find("meta").find("obs_post_id").text()+"</td></tr>"; 
			content += "<tr><th>고정 관측소 명</th><td>"+$(data).find("result").find("meta").find("obs_post_name").text()+"</td></tr>"; 
			content += "<tr><th>고정 관측소 위도</th><td>"+$(data).find("result").find("meta").find("obs_lat").text()+"</td></tr>"; 
			content += "<tr><th>고정 관측소 경도</th><td>"+$(data).find("result").find("meta").find("obs_lon").text()+"</td></tr>"; 
			content += "<tr><th>금일요청가능횟수</th><td>"+$(data).find("result").find("meta").find("obs_last_req_cnt").text()+"</td></tr>"; 
			content += "</table>";
		}
		var popup = new OpenLayers.Popup.FramedCloud(ObsCode, 
			new OpenLayers.Geometry.Point(lon,lat).transform(new OpenLayers.Projection("EPSG:4326"),map.projection).getBounds().getCenterLonLat(), null
			,content
			,null
			,false 
		);
		map.addPopup(popup);
	}