$(function(){
	var date = new Date();
	var day = date.getDate();
	var mon = date.getMonth()+1;
	var year = date.getFullYear();
	mon+="";
	day+="";
	if(mon.length < 2){
		mon = "0"+mon;
	}
	if(day.length < 2){
		day += "0"+day;
	}


	$( "#datepickerSdate" ).datepicker();
	$( "#datepickerSdate" ).datepicker( "option", "dateFormat", "yy-mm-dd" );
	$( "#datepickerSdate" ).val(year+"-"+mon+"-"+day);

	var width = $("#dataDiv").outerWidth();
	$("#dataDiv" ).animate({ "right": "-="+width+"px" },"fast",function(){$( "#dataDiv").show();} );
	$("#dataDiv" ).animate({ "right": "+=20px"}, "slow");
	$( "#progressbar" ).progressbar({ value: false});

	$(".databtn").on('click',function(){
		if($("#openDiv").attr("alt") == "닫기"){
			hideDataList();
		}else{
			showDataList();
		}
	});

	$('.schbtn').on('click', function() {	
		if($("#openTop").attr("alt") == "닫기"){
			hideSearchDiv();
		}else{
			showSearchDiv();
		}
	});

	$('#obsCode').on('change', function() {	
		setMarker(map,eval("obslonlat."+this.value).lon,eval("obslonlat."+this.value).lat)
	});

	$( "#progressbar" ).progressbar({ value: false});
});

var keepOffsetOn = function(obj){
	var offset = $(obj).offset();
	$(obj).css("left",offset.left+"px");
	$(obj).css("right","auto");
}

var keepOffsetOff = function(obj){
	var width = $(obj).outerWidth()-20;
	$(obj).css("right","-"+width+"px");
	$(obj).css("left","auto");
}


var showDataList = function(){
		$("#dataDiv").stop();
		var width = $(".dataDiv").outerWidth();
		$("#dataDiv").animate({ "right": "+="+width}, "slow" );
		$("#openDiv").attr("alt","닫기");
		$("#openDiv").attr("src","img/btn_right_c.png");
	};	
var hideDataList = function(){
		$("#dataDiv").stop();
		var width = $(".dataDiv").outerWidth();
		$("#dataDiv").animate({ "right": "-="+width}, "slow");		
		$("#openDiv").attr("alt","열기");
		$("#openDiv").attr("src","img/btn_right_o.png");
	};	

var showSearchDiv = function(){
		var height = $("#searchKeyTop").outerHeight();	
		$(".stop" ).animate({"top": "+="+height+"px" }, "slow" );
		$("#openTop").attr("alt","닫기");
		$("#openTop").attr("src","img/btn_top_c.png");
	};	
var hideSearchDiv = function(){
		var height = $("#searchKeyTop").outerHeight();
		$(".stop" ).animate({"top": "-="+height+"px" }, "slow" );
		$("#openTop").attr("alt","열기");
		$("#openTop").attr("src","img/btn_top_o.png");
	};