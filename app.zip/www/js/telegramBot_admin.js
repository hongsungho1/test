/* ***************************************************************** */
// 설치 npm 
//
/* ***************************************************************** */

const { parse } = require("querystring");



/* ***************************************************************** */
// I/F 필드 정의 
/* ***************************************************************** */
/*

*/
/* ***************************************************************** */

/* ***************************************************************** */
/* 사용 예시 
    var adm = require(oAPP.path.join(__dirname, 'js/telegramBot_admin.js'));


    var retdata1 = await adm.send_ActButton(bot, msg);


    var retdata2 = await adm.callback_ActButton(bot, msg);


    retdata.RETCD <-- E:오류 
    retdata.RTMSG <-- 처리 메시지 
      
*/
/* ***************************************************************** */

/* ***************************************************************** */
/* 내부 광역 변수  
/* ***************************************************************** */

//JSON 파일 Read + parse 
async function _getFile_JSON(PATH){
    return new Promise( async (resolve, reject) => {

        oAPP.fs.readFile(PATH, 'utf8', function (err,data) {
            if (err) {
                resolve({});
                return;
            }
            
            try {
                resolve(JSON.parse(data));
            } catch (error) {
                resolve({});
            }
            
        });

    });
}


//js 파일 Read  
async function _getFile_JS(PATH){
    return new Promise( async (resolve, reject) => {

        oAPP.fs.readFile(PATH, 'utf8', function (err,data) {
            if (err) {
                resolve("");
                return;
            }
            
            try {
                resolve(data);
            } catch (error) {
                resolve("");
            }
            
        });

    });
}

/* ***************************************************************** */
/* 내부 전역 펑션 
/* ***************************************************************** */

const CHKKEYWORLD01  = RegExp("/ADMIN", "");

let CONFIG  = {};

let T_ADMIN = [];
    T_ADMIN.push(2142197003);  //홍영선
    T_ADMIN.push(5311179178);  //홍성호
    T_ADMIN.push(2141804045);  //박은섭
    T_ADMIN.push(498542502);   //이청윤

/* ================================================================= */
/* Export Module ADMIN관리 기능 버튼 
/* ================================================================= */
exports.send_ActButton = async function(BOT, MSG){

    return new Promise( async (resolve, reject) => {
        
        //테스트 모드 일 경우 
        if(!oAPP.remote.app.isPackaged){ T_ADMIN.push(5311179178); debugger; }
        
        //입력 값이 존재시만 하위 수행
        if( (typeof MSG.text === "undefined") && MSG.text === "" ){ resolve({ RETCD:"S", RTMSG:"", ISSTOP:false }); return; }

        //입력 키워드 대문자 전환
        var txt_uper = MSG.text.toUpperCase();

        //입력 키워드에 /admin 여부 점검 - 존재하지않으면 종료 
        if(txt_uper.search(CHKKEYWORLD01) < 0 ){ resolve({ RETCD:"S", RTMSG:"", ISSTOP:false }); return; }

        //Admin 여부 점검 
        var IsADM = T_ADMIN.filter(e=> e === MSG.chat.id);
        if(IsADM.length == 0){ resolve({ RETCD:"S", RTMSG:"", ISSTOP:false }); return; }

        //관리자 액션 버튼 정보 얻기
        CONFIG.act_buttons = await _getFile_JSON(oAPP.path.join("D:\\TELEGRAM_ADMIN", "config_inline_button.json"));

        if(CONFIG.act_buttons.length == 0){ 

            var sendMsgTxt = "⚠ 관리자 권한 기능이 없습니다 ⚠";

            await BOT.sendMessage(MSG.chat.id, sendMsgTxt);

            resolve({ RETCD:"S", RTMSG:"", ISSTOP:true }); 

            return;
        }

        var sendMsgTxt = "✅ 관리자 권한 기능 리스트 ";

        await BOT.sendMessage(MSG.chat.id, sendMsgTxt, {
            "reply_markup": {
                "inline_keyboard": CONFIG.act_buttons
            }
        });

        resolve({ RETCD:"S", RTMSG:"", ISSTOP:true });

    });

};


/* ================================================================= */
/* Export Module ADMIN 관리버튼 선택에 대한 후속 처리  callbackQuery
/* ================================================================= */
exports.callback_ActButton = async function(BOT, CALLBACKQUERY){
    return new Promise( async (resolve, reject) => {
        
        if(typeof CALLBACKQUERY.data === "undefined"){ resolve({ RETCD:"S", RTMSG:"", ISSTOP:false }); return; }
        if(CALLBACKQUERY.data === ""){ resolve({ RETCD:"S", RTMSG:"", ISSTOP:false }); return; }

        if(typeof CALLBACKQUERY === "undefined"){ resolve({ RETCD:"S", RTMSG:"", ISSTOP:false }); return; }
        if(typeof CALLBACKQUERY.message === "undefined"){ resolve({ RETCD:"S", RTMSG:"", ISSTOP:false }); return; }
        if(typeof CALLBACKQUERY.message.chat === "undefined"){ resolve({ RETCD:"S", RTMSG:"", ISSTOP:false }); return; }
        if(typeof CALLBACKQUERY.message.chat.id === "undefined"){ resolve({ RETCD:"S", RTMSG:"", ISSTOP:false }); return; }
        if(typeof CALLBACKQUERY.message.reply_markup === "undefined"){ resolve({ RETCD:"S", RTMSG:"", ISSTOP:false }); return; }
        if(typeof CALLBACKQUERY.message.reply_markup.inline_keyboard === "undefined"){ resolve({ RETCD:"S", RTMSG:"", ISSTOP:false }); return; }
        //테스트 모드 일 경우 
        //if(!oAPP.remote.app.isPackaged){  debugger; }

        let jsData = await _getFile_JS(oAPP.path.join("D:\\TELEGRAM_ADMIN", "js", CALLBACKQUERY.data ));

        if(jsData === ""){
            resolve({ RETCD:"S", RTMSG:"", ISSTOP:false });
            return;

        }

        try {
            eval(jsData);
        } catch (err) {

            var sendMsgTxt = "🚫 관리자 기능 스크립트 오류 🚫 \n\n " 
                           + "JS 파일명 : " + oAPP.path.join("D:\\TELEGRAM_ADMIN", "js", CALLBACKQUERY.data )
                           + " \n\n "
                           + err.toString();
                           + " \n\n ";

            await BOT.sendMessage(CALLBACKQUERY.message.chat.id, sendMsgTxt);

            resolve({ RETCD:"E", RTMSG:sendMsgTxt, ISSTOP:true });
            return;
        }
        
        resolve({ RETCD:"S", RTMSG:"", ISSTOP:true });

    });
}