const oAPP = {
    onStart:function(){
        this.remote = require('@electron/remote');
        this.ipcMain = this.remote.require('electron').ipcMain;
        this.ipcRenderer = require('electron').ipcRenderer;
        this.fs = this.remote.require('fs');
        this.path = this.remote.require('path');
        this.qs   = this.remote.require('querystring');
        this.Multiparty = require('multiparty');
        this.axios = this.remote.require('axios');
        this.Tray = this.remote.require("electron").Tray;
        this.ip = require("ip");
        this.require = require;
        this.__dirname = __dirname;
        this.Buffer = Buffer;
        this.NodeSSH = require('node-ssh').NodeSSH;
        this.desktopCapturer = this.remote.require('electron').desktopCapturer;
        this.admTelegram = require(oAPP.path.join(__dirname, 'js/telegramBot_admin.js'));
        this.LOGO_IMG_PATH = this.path.join(__dirname, "img", "logo.png");


        //this.crtServ = require(oAPP.path.join(__dirname, 'js/CreateServer.js'));
        
        //분기 
        //데스크탑 이름 



        return;
        
        var http = require('http');
            http.createServer( async function(req, res) {

                debugger;

                //서비스 점검
                if(!oAPP.onChkService(req, res)){ return; }

                
                //요청 서비스 정보 추출 - 서비스 PATH , 파라메터
                var sINFO = await oAPP.onServiceInfo(req, res);

                debugger;
            
                //var retn = require(oAPP.path.join(__dirname, 'js/test1.js'));
        
        
                res.writeHead(200, { 'Content-Type': 'text/html' });
                //res.writeHead(200, { 'Content-Type': 'application/json' });
               
                res.end('aaa');

            }).listen(1333, '172.30.1.35');

    },


    onCreateNote:()=>{

        var { menubar } = oAPP.remote.require('menubar');

        var option = {
            "height": 300,
            "width":  300,
            "resizable": true,
            "frame":true,
            "show":false,
            "webPreferences":{
                "devTools": true,
                "nodeIntegration": true,
                "enableRemoteModule":true,
                "contextIsolation": false,
                "webSecurity": false,
                "nativeWindowOpen": true
            }              

        };


        const mb = menubar({ icon:"F:\\cordova_u4a\\electron\\U4A_HTTP_CLIENT_SERVER\\www\\img\\logo.png",
                             browserWindow:option
                          });

        //윈도우 객체 생성이후 이벤트 
        mb.on('after-create-window', ()=>{

            mb.window.openDevTools();
            mb.window.loadURL(`file://${__dirname}/hello.html`);
            mb.window.show();

            oAPP.remote.require('@electron/remote/main').enable(mb.window.webContents);
       
        });
        
        mb.app.commandLine.appendSwitch('disable-backgrounding-occluded-windows', 'true');
        mb.showWindow();
        
        


    },

    //비디오 팝업 
    onVideoPopup: ()=>{
        oAPP.remote.getCurrentWindow().webContents.closeDevTools();
        var op = {
            "height": screen.availHeight,
            "width":  screen.availWidth,
            //"acceptFirstMouse": true,
            "resizable": true,
            "fullscreenable": true,
            "alwaysOnTop":true,
            //"maximizable": false,
            //"minimizable": false,
            "frame":true,
            "show":false,
            "parent": oAPP.remote.getCurrentWindow(),
            "webPreferences":{
                "devTools": true,
                "nodeIntegration": true,
                "enableRemoteModule":true,
                "contextIsolation": false,
                "webSecurity": false,
                "nativeWindowOpen": true
            }              

        };

        oAPP.remote.getCurrentWindow().webContents.closeDevTools();
        var oWIN = new oAPP.remote.BrowserWindow(op);
        oWIN.setMenuBarVisibility(false);
        oWIN.setOpacity(0);
        var url = `file://${__dirname}/ScreenRecord_test/index.html`;
        oWIN.loadURL(url);
	    oWIN.webContents.on('did-finish-load', function () {
            oWIN.show();

            oWIN.webContents.openDevTools();


        });

        oAPP.remote.require('@electron/remote/main').enable(oWIN.webContents);


    },

    //프로그레스 팝업 
    onProgress:()=>{

        var op = {
            "height": 100,
            "width":  500,
            "acceptFirstMouse": true,
            "resizable": false,
            "fullscreenable": true,
            "alwaysOnTop":true,
            "maximizable": false,
            "minimizable": false,
            "frame":false,
            "show":false,
            "modal":false,
            "parent": oAPP.remote.getCurrentWindow(),
            "webPreferences":{
                "devTools": true,
                "nodeIntegration": true,
                "enableRemoteModule":true,
                "contextIsolation": false,
                "webSecurity": false,
                "nativeWindowOpen": true
            }              

        };


        oAPP.remote.getCurrentWindow().webContents.closeDevTools();
        var oWIN = new oAPP.remote.BrowserWindow(op);
        oWIN.setMenuBarVisibility(false);
        var url = `file://${__dirname}/Progress.html`;
        oWIN.loadURL(url);
	    oWIN.webContents.on('did-finish-load', function () {
            oWIN.show();

            oWIN.webContents.openDevTools();


  
        });

        oAPP.remote.require('@electron/remote/main').enable(oWIN.webContents);

        var ggg = 0;

        var zzz = setInterval(() => {
            ggg = ggg + 10;
            oWIN.webContents.send('IF-progress', {value:ggg});

            if(ggg === 100){ clearInterval(zzz);  
            
                setTimeout(() => {
                    oWIN.close();
                }, 700);
            }

        }, 1000);


    },


    onPopuptest:()=>{

        var op = {
            "height": 500,
            "width":  500,
            "acceptFirstMouse": true,
 
            "alwaysOnTop":true,
            "maximizable": false,
            "minimizable": false,
            "show":true,
            "transparent": false,
            "frame": false,
            //"titleBarStyle": "hidden",
            "parent": oAPP.remote.getCurrentWindow(),

            "webPreferences":{
                "devTools": true,
                "nodeIntegration": true,
                "enableRemoteModule":true,
                "contextIsolation": false,
                "webSecurity": false,
                "nativeWindowOpen": true
            }              

        };

        const windowState = oAPP.remote.require('electron-window-state');

        /*
        let mainWindowState = windowState({
            defaultWidth: 500,
            defaultHeight: 300
        });

        op.x = mainWindowState.x;
        op.y = mainWindowState.y;
        op.width =  mainWindowState.width;
        op.height = mainWindowState.height;

        oAPP.remote.getCurrentWindow().webContents.closeDevTools();
  */
        var oWIN = new oAPP.remote.BrowserWindow(op);
        //mainWindowState.manage(oWIN);

      

        oWIN.setMenuBarVisibility(false);

        var url = `file://${__dirname}/test1.html`;
        oWIN.loadURL(url);
	    oWIN.webContents.on('did-finish-load', function () {
            oWIN.show();

            oWIN.webContents.openDevTools();
        
  
        });

        oAPP.remote.require('@electron/remote/main').enable(oWIN.webContents);


    },

    //텔레그램 ADMIN 테스트 
    onTelegramADM:()=>{

        const TelegramBot = oAPP.remote.require('node-telegram-bot-api');
        const token= '5631746596:AAG-Mxhmig-yVId7NP_0RzJj1QBDlBXXmVc';

        const bot = new TelegramBot(token, {polling: true});

        bot.on('callback_query', async function onCallbackQuery(callbackQuery) {
            // increment counter when everytime the button is pressed
            
            var retdata = await oAPP.admTelegram.callback_ActButton(bot, callbackQuery);
            if(retdata.ISSTOP){ return; }

            console.log(retdata);
            return;
            console.log(callbackQuery.message.chat.id );
            console.log(callbackQuery.data );
            console.log(callbackQuery.message.reply_markup.inline_keyboard );

            //callbackQuery.from.id  //대상 chatid
            //callbackQuery.data //버튼 선택 코드값 
            //callbackQuery.message.reply_markup.inline_keyboard //버튼 리스트 현황 


        });
        

        bot.on('message', async (msg) => {
            const chatId = msg.chat.id;
          

            //admin 대상일 경우 

            // 키워드 /ADMIN <-
            var retdata = await oAPP.admTelegram.send_ActButton(bot, msg);
            if(retdata.ISSTOP){ return; }
            console.log(retdata);


            /*
            var inline_keyboard = require(oAPP.path.join(__dirname, "data", "inline_keyboard.json"));

            var welcome = "안녕하세요 관리자 " + msg.chat.first_name + " " + msg.chat.last_name + " 님";

            await bot.sendMessage("5311179178", welcome, {
                "reply_markup": {
                    "inline_keyboard": inline_keyboard
                }
            });
            */


            // send a message to the chat acknowledging receipt of their message
            //bot.sendMessage(chatId, 'Received your message');
            
       });

    },





    onPreview:()=>{

        
            
            
        

      //미디어 소스 정보 추출 
      oAPP.desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: 300, height: 300 }  }).then(async sources => {
              
        debugger;
        if(sources.length == 0){ return; }

        for (let index = 0; index < sources.length; index++) {
            var source = sources[index];

            var LID = "pr" + index;

            document.getElementById(LID).src = source.thumbnail.toDataURL(); 
            
        }


      });



    },




    onServer: ()=>{


        var cors = require('cors');
        var express = require('express');
        var bodyParser = require('body-parser');
        var app = express();

        
    
        var safesitelist = ['http://192.168.0.8:3000', 'http://www.u4ainfo.com']

        var corsOptions = {
            origin: function(origin, callback) {
                var issafesitelisted = safesitelist.indexOf(origin) !== -1;
                callback(null, issafesitelisted);
            },
            credentials: false
        }

        app.use(express.static('public'));
        //app.use(bodyParser.json());
        //app.use(bodyParser.urlencoded({extends:true}));
        //app.use(cors());

        app.get('/', cors(corsOptions), function (req, res) {
            res.header("Access-Control-Allow-Origin", "*");
            res.status(200);
            res.send('Hello World');
        });

        app.listen(3000, '192.168.0.8');
       
          
        


    },


    onServer2: ()=>{


        var http = require('http');
            http.createServer( async function(req, res) {

                res.end('aaa');
            }).listen(3000, '192.168.0.8');


    },


    onHTTPS: ()=>{

        const http = require("http");
        const https = require("https");
        const express = require("express");

        const app = express();  // https
        const app2 = express();  // http

        const credentials = {
            key: "",
            cert: ""
        
        };

        const httpServer = http.createServer(app2);
        const httpsServer = https.createServer(credentials, app);
        

            // 80 port -- http
            app2.get("/", (req, res) => {
                console.log("------ http get / -----" + (new Date()).toLocaleString());
                console.log("req.ip => " + req.ip);
                console.log("req.hostname => " + req.hostname);
                console.log(req.url);
                console.log(req.originalUrl);

                res.send("<h1>HTTP Server running on port 80</h1>");
            });

            // 3000 port -- https
            app.get("/", (req, res) => {
                console.log("------ https get / -----" + (new Date()).toLocaleString());
                console.log("req.ip => " + req.ip);
                console.log("req.hostname => " + req.hostname);
                console.log(req.url);
                console.log(req.originalUrl);

                res.send("<h1>HTTPS Server running on port 3000</h1>");
            });

        
            httpServer.listen(80, () => {
                console.log((new Date()).toLocaleString());
                console.log('HTTP Server running on port 80');
            });
            
            httpsServer.listen(3000, ()=>{
                console.log((new Date()).toLocaleString());
                console.log(`HTTPS -- listening on port 3000 ...`);
            });
  



    },


    telFILE: async ()=>{

        const axios = oAPP.remote.require('axios');
        const FormData = oAPP.remote.require('form-data');
    
        const url = `https://api.telegram.org/bot5462273470:AAFtKZ14L-EBxyH84KF7tunAYxf_AFVbpTQ/sendDocument`;
                    //`https://api.telegram.org/bot5462273470:AAFtKZ14L-EBxyH84KF7tunAYxf_AFVbpTQ/sendDocument`    
         //const url = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendDocument`;
    
        
        const formData = new FormData();
    
        formData.append('chat_id', "5311179178");
    
        formData.append('document', oAPP.fs.createReadStream('D://video//logo.png'), 'logo.png');
    
        aaaa = await axios.post(url, formData, {
            headers: formData.getHeaders(),
    
        });

        //aaaa.data.result.document.file_id
        //aaaa.data.result.document.thumb.file_id
        debugger;


    
  
        var LURL = "https://api.telegram.org/bot5462273470:AAFtKZ14L-EBxyH84KF7tunAYxf_AFVbpTQ/getFile?file_id=BQACAgUAAx0EbFY8gAADgGNzphEH7rv_xcimN9rMqPfdjGR-AAKGBwACa2iYV9toT_iwYHbXKwQ";
        var LURL = "https://api.telegram.org/bot5462273470:AAFtKZ14L-EBxyH84KF7tunAYxf_AFVbpTQ/getFile?file_id=BAACAgUAAx0EbFY8gAADf2Nzpgy5Lq0EXVpNz3n1anxQAc3RAAKFBwACa2iYV3ws2E3oZnAeKwQ";
        var LURL = "https://api.telegram.org/bot5462273470:AAFtKZ14L-EBxyH84KF7tunAYxf_AFVbpTQ/getFile?file_id=" + aaaa.data.result.document.file_id;
        var xhttp = new XMLHttpRequest();
        xhttp.onload = (e)=>{ 
            
            var aa = JSON.parse(e.target.response);
             
            debugger;
            return;
            oAPP.telFILE2(aa.result);
        
        };


        xhttp.onerror = (e)=>{ debugger; };

        xhttp.open("GET", LURL, true);
        xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
        xhttp.withCredentials = false; 
        xhttp.send();


    },

    telFILE2:(result)=>{
        
        var LURL = "https://api.telegram.org/file/bot" + "5462273470:AAFtKZ14L-EBxyH84KF7tunAYxf_AFVbpTQ" + "/" + result.file_path;


        var xhttp = new XMLHttpRequest();
        xhttp.onload = async (e)=>{ 
            
            const {
                arrayBufferWithMime,
                arrayBufferMimeDecouple 
              } = require('arraybuffer-mime');

            
            debugger;
            var fileTypeFromBuffer = require("file-type");
        
            const blob = new Blob([e.target.response], {
                type: 'plain/text',
                endings: 'native'
            });

            var exent = await fileTypeFromBuffer(blob);


            debugger;
             
           
        
        };


        xhttp.onerror = (e)=>{ debugger; };

        xhttp.open("GET", LURL, true);
        xhttp.withCredentials = false;
        //xhttp.responseType = 'arraybuffer'; 
        //xhttp.responseType = 'blob'; 
        xhttp.send();

    },    

    recording:()=>{


        var ret = require(oAPP.path.join(__dirname, 'ScreenRecord/ScreenRecording.js'));
        ret.start(oAPP.remote, "sap_horizon_dark1");


    },

    //요청 서비스 정보 추출 - 서비스 PATH , 파라메터
    onServiceInfo: (req, res)=>{

        var T_path = req.url.split("?");
        var retData = {};
            retData.PATH  = T_path[0];
            retData.PARAM = [];

        switch (oAPP.onGetMethod(req)) {
            case "GET": //GET 방식 파라메터 정보 얻기
                if(typeof T_path[1] === "undefined"){ return retData; }

                var Params = oAPP.qs.parse(T_path[1]);
            
                for (var prop in Params) {
                    
                    var sLine = {};
                        sLine.NAME  = prop;
                        sLine.VALUE = Params[prop];
                        retData.PARAM.push(sLine);

                }

                return retData;

            case "POST": //POST 방식 파라메터 정보 얻기

                //만일 POST 방식일 경우라도 URL 뒤 파라메터 정보 존재여부 확인
                if(typeof T_path[1] !== "undefined"){
                    var Params = oAPP.qs.parse(T_path[1]);
                    
                    for (var prop in Params) {
                        
                        var sLine = {};
                            sLine.NAME  = prop;
                            sLine.VALUE = Params[prop];
                            retData.PARAM.push(sLine);

                    }
                }

                return new Promise(function(resolve, reject) {

                    var oForm = new oAPP.Multiparty.Form();
                        oForm.parse(req, (err, fields, files)=>{

                            if(err){ resolve(retData); }

                            for (var prop in fields) {
                    
                                var sLine = {};
                                    sLine.NAME  = prop;
                                    sLine.VALUE = fields[prop][0];
                                    retData.PARAM.push(sLine);
            
                            }

                            resolve(retData);

                        });

                });

            default:

                //요청 유형이 ajax(비동기통신) 여부 점검
                if(oAPP.onChkAjax(req)){
                    res.writeHead(500, { 'Error': 'X' });
                    res.end("bad request");

                }else{
                    res.writeHead(500, { 'Content-Type': 'text/html' });
                    res.end(oAPP.onErrorPage("500","Server Error", "bad request"));

                }
                
                return;
        }

    },

    //서비스 점검 
    onChkService:(req, res)=>{

        var T_path = req.url.split("?");
        var Lurl = T_path[0].replace("/","");

            if(Lurl === ""){ 
                
                //요청 유형이 ajax(비동기통신) 여부 점검
                if(oAPP.onChkAjax(req)){
                    res.writeHead(500, { 'Error': 'X' });
                    res.end("page not found");

                }else{
                    res.writeHead(500, { 'Content-Type': 'text/html' });
                    res.end(oAPP.onErrorPage("500","Server Error", "page not found"));

                }
                
                return false; 
            
            }

        return true; 


    },
    //오류 페이지 형식
    onErrorPage:(code, title, msg)=>{

        var Lhtml = oAPP.fs.readFileSync(oAPP.path.join(__dirname, 'error.html'), 'utf8');
            Lhtml = Lhtml.replace("&CODE&",  code);
            Lhtml = Lhtml.replace("&TITLE&", title);
            Lhtml = Lhtml.replace("&MSG1&",  msg);

        return Lhtml;

    },

    //요청 Method 정보 추출
    onGetMethod:(req)=>{

        var Lmethod = req.method;

        if(req.method === "GET"){ return Lmethod = "GET"; }
        if(req.method === "POST"){ return Lmethod = "POST"; }

        for (var i = 0; i < req.rawHeaders.length; i++) {
            var LVal = req.rawHeaders[i];
            if(LVal === "POST"){ Lmethod = "POST"; break; }
            
        }

        if(Lmethod !== "GET" && Lmethod !== "POST"){

            if(typeof req.headers['access-control-request-method'] !== "undefined"){
                Lmethod = req.headers['access-control-request-method'];

            }
        
        }

        return Lmethod;
        
    },

    //요청 유형이 ajax(비동기통신) 여부 점검
    onChkAjax:(req)=>{
        
        if(typeof req.headers["access-control-request-headers"] !== "undefined" ) { return true; }

        var isAJAX  = false;
        for (var i = 0; i < req.rawHeaders.length; i++) {
            var LVal = req.rawHeaders[i];
            if(LVal === "Access-Control-Request-Headers"){ isAJAX = true; break; }
            
        }

        return isAJAX;

    },


    onAuthCall: (URL)=>{

        process.traceProcessWarnings = true;
        // 테스트 웹뷰 
        var op = {
            "height": 900,
            "width": 1100,
            "modal":false,
            "fullscreen":false,
            "alwaysOnTop":true,
            "webPreferences":{
                "devTools": true,
                "contextIsolation":false,
                "nodeIntegration":true,
                "nativeWindowOpen": false,
                "enableRemoteModule":true,
                "contextIsolation": false,
                "webSecurity": false,
                "webviewTag":true,
                "nodeIntegrationInSubFrames":true,
                "plugins":true,
                "javascript":true
        
            }
            
        };
    
    
        oAPP.authWIN = new oAPP.remote.BrowserWindow(op);
        oAPP.authWIN.loadURL(`file://${__dirname}/auth.html`);
        oAPP.authWIN.webContents.on('did-finish-load', ()=> {
        oAPP.authWIN.show();
            oAPP.authWIN.webContents.send('IF_U4A_APP', { config:URL });
    
        });
    
        oAPP.authWIN.on('close', ()=> {
           delete oAPP.authWIN;   
        }); 
    

        var remote = require('@electron/remote');
        remote.require('@electron/remote/main').enable(oAPP.authWIN.webContents);

    }
    
    
};

GGGG = "";

//Device ready 
document.addEventListener('deviceready', onDeviceReady, false);
function onDeviceReady() {
    oAPP.onStart();

    return;

    window.onbeforeunload = (e) => { 
        debugger;
        var oWin = oAPP.remote.getCurrentWindow();
        oAPP.otray = new oAPP.Tray(oAPP.LOGO_IMG_PATH);
        oAPP.otray.setToolTip("tttt");
        const {Menu} = oAPP.remote.require('electron');
        const contextMenu = Menu.buildFromTemplate([
            {label: 'Item1', type: 'radio'},
            {label: 'Item2', type: 'radio'},
            {label: 'Item3', type: 'radio', checked: true},
            {label: 'Item4', type: 'radio'}
        ]);

        oAPP.otray.setContextMenu(contextMenu);


        oAPP.otray.displayBalloon({title:"aaa", content:"zzzzz"});

 

        oAPP.otray.on("click", (e)=>{ 
            oWin.destroy();
            oAPP.otray.destroy(); 

        
        });



        oWin.hide();

        if(GGGG === ""){

            return false;

        }

     

    };

}






let  oWIN = null;

function Lfn_WEBVIEW(URL){

    // 테스트 웹뷰 
    var op = {
     "height": 900,
     "width": 1100,
     "modal":false,
     "fullscreen":false,
     "alwaysOnTop":true,
     "webPreferences":{
         "devTools": true,
         "nodeIntegration":true,
         "nativeWindowOpen": false,
         "contextIsolation": false,
         "webSecurity": false,
         "webviewTag":true
 
     }
     
 };


 oWIN = new oAPP.remote.BrowserWindow(op);
 oWIN.loadURL(`file://${__dirname}/auth.html`);
 oWIN.webContents.on('did-finish-load', ()=> {
    oWIN.show();

    oWIN.webContents.send('IF_U4A_APP', { config:URL });

 });

 oWIN.on('close', ()=> {
   oWIN = null;    
}); 



 var remote = require('@electron/remote');
    remote.require('@electron/remote/main').enable(oWIN.webContents);

}

function gfn_parent(){


    return oAPP;

}


async function gfn_telegram_send_doc(){

    const axios = oAPP.remote.require('axios');
    const FormData = oAPP.remote.require('form-data');

    const url = `https://api.telegram.org/bot5462273470:AAFtKZ14L-EBxyH84KF7tunAYxf_AFVbpTQ/sendDocument`;
    //const url = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendDocument`;

    const formData = new FormData();
    formData.append('chat_id', "5311179178");
    formData.append('document', oAPP.fs.createReadStream('D://video//vis_company.jpg'), 'testdddd.jpg');

    await axios.post(url, formData, {
        headers: formData.getHeaders(),
    });

}


async function gfn_ssh(){

    const {NodeSSH} = require('node-ssh');
    const SSH = new NodeSSH();
    const Lpassword = '#u4aRnd$';
    var ssh = await SSH.connect({
        host: 'u4arnd.iptime.org',
        username: 'u4arnd',
        port: 9541,
        password : Lpassword,
        tryKeyboard: true,
    });

    var tt = await ssh.getDirectory('F://cordova_u4a//electron//U4A_HTTP_CLIENT_SERVER//www//data', '/mnt/Data/U4ARND/u4arnd');

}


const oSSH = {

    _SSH:null,

    //연결
    onConect: async ()=>{

        const {NodeSSH} = require('node-ssh');
        const Lpassword = '#u4aRnd$';

        var SSH = new NodeSSH();

        oSSH._SSH = await SSH.connect({
            host: 'u4arnd.iptime.org',
            username: 'u4arnd',
            port: 9541,
            password : Lpassword,
            tryKeyboard: true,
        });

    },

    //파일 ?
    onIsFile: async (path)=>{
        return new Promise((resolve, reject) => {

            if(path == ""){ resolve(false);  return; }

            var Lcommand = "if test -f '" + path +"'; then  echo true; fi";
            oSSH._SSH.execCommand(Lcommand, { }).then(function(result) {

                if(result.stdout == "true"){ resolve(true); return;}

                resolve(false); 

            });

        });
    },

    //점검 디렉토리
    onChk_Directory: async (FPATH)=>{
        return new Promise((resolve, reject) => {

            if(FPATH == ""){ resolve(false);  return; }

            var Lcommand = "if test -f '" + FPATH +"'; then  echo true; fi";
            var Lcommand = "if [ -d " + FPATH + " ]; then  echo true; fi";
            oSSH._SSH.execCommand(Lcommand, { }).then(function(result) {
                if(result.stdout == "true"){ resolve(true); return;}

                resolve(false); 

            });

        });
    },

    //디렉토리 경로 정보 추출
    ongetDirectoryInfo: async (FPATH)=>{
        return new Promise((resolve, reject) => {
            var Lfpath = FPATH;
            if(typeof FPATH == "undefined"){ Lfpath = "u4arnd";  }
            if(Lfpath == ""){ Lfpath = "u4arnd";  }

            var Lcommand = "ls cd "+ Lfpath + " -a";
            oSSH._SSH.execCommand(Lcommand, { }).then(function(result) {

                if(result.stdout == ""){ resolve([]); return;}

                resolve(result.stdout.split("\n"));

            });

        });

    },

    //디렉토리 경로 정보 추출
    ongetDirectoryALL: async ()=>{

        var RET = [];

        return new Promise( async (resolve, reject) => {

           

            async function getDirectory(path){

                var Lcommand = "ls cd "+ path + " -a";
                var ret = await oSSH._SSH.execCommand(Lcommand, { });
                if(ret.stdout === ""){ resolve(RET); return; }

                return ret.stdout.split("\n");


            }

            var T_PATH = await getDirectory("u4arnd");
            debugger;
            var rootPATH = "",
                L_PATH   = "";

            for (let i = 0; i < T_PATH.length; i++) {
                var S_PATH = T_PATH[i];
                if(i == 0){ rootPATH = S_PATH.replace(":","");  continue; }

                L_PATH = rootPATH + "/" + S_PATH;
                var Lcommand = "ls cd "+ L_PATH + " -a";
                var ret = await oSSH._SSH.execCommand(Lcommand, { });
                
            }


        });

    }

};





