

var aaa = "aaaa";



exports.add = function(a, b){
    return aaa;
}
