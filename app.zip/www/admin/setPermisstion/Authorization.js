
/* ================================================================= */
// 사용 예시 
// var ret = require(oAPP.path.join(__dirname, 'admin', 'setPermisstion', 'Authorization.js'));
//     ret.setAuth({});
//                     
// 
/* ================================================================= */
//


/* ================================================================= */
/* Export Module Function 
/* ================================================================= */
exports.setAuth = async function(sParams){
    debugger;


    let CryptoJS = require(oAPP.path.join(__dirname, 'admin', 'setPermisstion', 'crypto-js.min.js'));

    debugger;
    






};