/*================================================================ */
/* API 

이미지 전송 
await oAPP.BOT.sendPhoto("5642428269", "https://www.u4ainfo.com/images/common/logo.png",{caption: "안녕 \n 방가 \n 하이"});

내 위치 전송 상대방에게 지도 표시해줌
await oAPP.BOT.sendLocation("5642428269", '20.080560504246307', '-98.36879789829254' );

????
await oAPP.BOT.sendSticker(
  "5642428269",
  "https://www.gstatic.com/webp/gallery/1.webp"
)

//지도 표현 + 내역 까지 
await oAPP.BOT.sendVenue("5642428269", "20.080560504246307", "-98.36879789829254", "안녕", "https://www.gstatic.com/webp/gallery/1.webp");


//버튼 + 텍스트 
  await  zz.sendMessage("5311179178", "Welcome", {
        "reply_markup": {
            "inline_keyboard":
                [
                    [
                        { text: 'AAA', callback_data: 'AAA11' }
                    ],
                    [
                        { text: 'BBB', callback_data: 'BBB22' }
                    ]
                ]
        }
    });

*/
/*=============================================================== */

const oAPP = {
    onStart: async function(){
        this.remote        = require('@electron/remote');
        this.ipcMain       = this.remote.require('electron').ipcMain;
        this.ipcRenderer   = require('electron').ipcRenderer;
        this.fs            = this.remote.require('fs');
        this.path          = this.remote.require('path');
        this.Tray          = this.remote.require("electron").Tray;
        this.LOGO_IMG_PATH = this.path.join(__dirname, "img", "logo.png");
        this.TelegramBot   = this.remote.require('node-telegram-bot-api');
        //this.TelegramToken = "5631746596:AAG-Mxhmig-yVId7NP_0RzJj1QBDlBXXmVc"; //SHHONG BOT 토큰키
        //this.TelegramToken = "5462273470:AAFtKZ14L-EBxyH84KF7tunAYxf_AFVbpTQ";   //U4A 법인 BOT 토큰키 
        this.TelegramToken = "";   //U4A 법인 BOT 토큰키 
        //this.isADM_ID      = 5311179178;        //SHHONG ADMIN BOT  채팅 ID
        this.isADM_ID      = 5642428269;          //U4A 법인 BOT 채팅 ID
        this.telegram_ME   = {};
        this.isChannel_ID  = "-1001817590912";    //U4A 법인 채널 전송 채팅 ID 
        this.MongClinet    = oAPP.remote.require('mongodb').MongoClient;
        this.BOT_learning = require(this.path.join(__dirname, 'js/BOT_learning.js')).BOT_Learning;
        this.BOT_answer   = require(this.path.join(__dirname, 'js/BOT_answer.js')).BOT_answer; 
        this.admTelegram  = require(oAPP.path.join(__dirname, 'js/telegramBot_admin.js'));       
        //this.MongDB_HOST   = 'mongodb://shhong:2wsxzaq1@localhost:27017/admin';
        //this.MongDB_HOST   = 'mongodb://118.34.215.175:27017';
        this.T_USER_INFO   = [];


        //WS 서비스 생성
        oAPP.onCrtWS();

        //MongoDB 접속 HOST 구성 
        var Lpw = "%U4aIde&";
            Lpw = encodeURIComponent(Lpw);
        this.MongDB_HOST = "mongodb://u4arnd:" + Lpw + "@118.34.215.175:9102/admin";


        //API 권한 접속 키 얻기
        var lsRet = await oAPP.onAuthGet();
        if(lsRet.RETCD == "E"){ alert(lsRet.RTMSG);  return; }

        //몽고 DB에 전체 사용자 정보 얻기
        oAPP.MongClinet.connect(oAPP.MongDB_HOST, async function(err, db) { 

            //텔레그램 관련 몽고 DB 연결
            oAPP.MongoDBO = db.db("TELEGRAM");

            oAPP.MongoDBO.collection("USER_INFO").find({}).toArray(function(err, result) {
                    //db.close();

                    //frame 로드 
                    document.getElementById("mainFrame").src = "frame.html";

                    if(err){ return; }
                    
                    //텔레그램 BOT 사용자 정보 전역변수 할당
                    oAPP.T_USER_INFO = result;

                    //텔레그램 채널전송 채팅 ID 존재여부 점검후
                    //존재하지않으면 몽고 DB 적재 처리
                    oAPP.onCheckAdminCHID(oAPP.T_USER_INFO);  
                        
            });

        });

    },

   //[펑션] Websocket 서비스 
   onCrtWS : ()=>{

        oAPP.WS = new WebSocket("ws://u4arnd.iptime.org:9401/U4A/TELEGRAM_BOT",['U4A-TELEGRAM-BOT']);
        oAPP.WS.onopen = function(e){
            console.log("ws ok");
        };

        //onMessage 
        oAPP.WS.onmessage = function(e){

            debugger;

            try {
                var sMSG  = JSON.parse(e.data);
                var sDATA = JSON.parse(sMSG.VALUE);                       
            } catch (error) {
                return;
                
            }

            //프로세스 코드별 분기
            switch (sDATA.PRCCD) {
                case "001": 
                    //서비스 재시작
                    oAPP.onServiceRESTART(sMSG.from_protocol, sDATA);
                    
                    break;
            
                default:
                    break;
            }
            
        };

        //소켓 오류
        oAPP.WS.onerror = function(){


        }

        //onClose
        oAPP.WS.onclose = function(e){
            console.log("ws close");

            if(typeof oAPP.WS !== "undefined"){ delete oAPP.WS; }

            //소켓 서비스가 종료 상태일경우 소켓 서비스 처리 펑션 재수행
            setTimeout(() => {
                oAPP.onCrtWS();
            }, 30000);

        }

    },

    //[펑션] - 서비스 재시작
    onServiceRESTART: (FROM_PROTOCOL, sDATA )=>{

        var sMSG = {to_protocol:FROM_PROTOCOL, from_protocol:"U4A-TELEGRAM-BOT", VALUE: {RETCD:"S", RTMSG:""} };
        oAPP.WS.send(JSON.stringify(sMSG));

        //서비스 재시작 OFF 처리 알림 메시지 
        fn_serviceONsendMsg("OFF");

        //서비스 Restart 3초후 실행
        setTimeout(() => {
            oAPP.remote.app.relaunch();
            oAPP.remote.app.exit();
        }, 10000);

    },


    //[펑션] - telegram bot 시작 
    onBOTstart: async ()=>{

        debugger;
        oAPP.BOT = new oAPP.TelegramBot(oAPP.TelegramToken, {polling: true});

        //BOT 정보
        oAPP.telegram_ME = await oAPP.BOT.getMe();


        //폴링 방식 오류 이벤트 수신 
        oAPP.BOT.on('polling_error', (error) => {
            console.error(error.code);  // => 'EFATAL'

        });


        //인라인 버튼 생성시 사용자가 버튼을 클릭시 callback 이벤트
        oAPP.BOT.on("callback_query", async (callbackQuery) => {

            //테스트 모드 일 경우 
            if(!oAPP.remote.app.isPackaged){ debugger; }
            
            var retdata = await oAPP.admTelegram.callback_ActButton(oAPP.BOT, callbackQuery);
            if(retdata.ISSTOP){ return; }

        });


        //텔레그램 봇채팅에서 수신 이벤트 - 일반 텍스트 기반
        oAPP.BOT.on('message', async (msg) => {
            debugger;

            //BOT ADMIN 이 전송했을 경우는 하위 수행 금지 
            if(msg.chat.id === oAPP.isADM_ID){ return; } 

            
            //Admin 프로세스?
            var retdata = await oAPP.admTelegram.send_ActButton(oAPP.BOT, msg);
            if(retdata.ISSTOP){ return; }


            //사용자 정보 기등록 사용자 여부 점검
            var T_USER = oAPP.T_USER_INFO.filter(e=>e.chat_id === msg.chat.id);

            //신규 사용자 일 경우 ..
            if(T_USER.length === 0){

                //텔레그램 신규 사용자 등록 및 
                //환영 메시지 처리 
                oAPP.onSetNewUser(msg);

                return;

            }

            //자동 응답 처리 
            oAPP.onAutoBOT(msg);
      
        });

    },

    //[펑션] - 텔레그램 신규 사용자 등록 및 환영 메시지 처리 
    onSetNewUser:(msg)=>{

        var USER_INFO = {
            "chat_id"   : msg.chat.id,         //채팅 ID 
            "first_name": msg.chat.first_name, //성
            "last_name" : msg.chat.last_name,  //이름
           
        };

        //환영 메시지 처리 
        async function lfn_webcomeMsg(U){

            //환영 본문
            var Lmsg = "";
            Lmsg = "😎 U4A BOT 오신걸 환영 합니다 😍"  
                 + " \n\n "
                 + "🏠 U4A Home"
                 + " \n "
                 + "https://www.u4ainfo.com/"
                 + " \n\n "
                 + "🏠 본사 Home"
                 + " \n "
                 + "http://www.infocg.co.kr/"                 
                 + " \n\n "
                 + "⭐ U4A 텔레그램 BOT 초대 URL"
                 + " \n "
                 + "https://t.me/U4A_INFO_BOT"                 
                 + " \n\n "
                 + "⭐ U4A 텔레그램 채널 초대 URL"
                 + " \n "
                 + "https://t.me/u4a_info"
                 + " \n\n " 

                 + "✅ BOT에게 다음 명령을 전송하여 학습시킬수 있습니다"
                 + " \n\n " 
                 + "BOT에게 학습 방법은 아래와 같이 채팅창에 질문을 입력합니다"
                 + " \n " 
                 + "➤  /me 우리집?"
                 + " \n\n "      
                 + "입력한 텍스트 위에 마우스 우클릭(모바일 에선 터치로 1초 이상) 실행"
                 + " \n " 
                 + "'답장' 이라는  문구를 클릭"
                 + " \n "  
                 + "그럼 '답장' 입력창이 열립니다"
                 + " \n " 
                 + "그 영역에 상위에서 질문에 대한 답변을 입력하고 전송을 누루면 예) 서울시..OO동.."
                 + " \n " 
                 + "정상적으로 입력했다는 메시지가 수신 될것입니다"
                 + " \n\n "  
              
                 + "그 다음부턴 검색창에 학습시킨 키워드를 입력하시면"
                 + " \n " 
                 + "등록된 기준으로 조회를 하실수 있습니다😎"
                 + " \n\n "
                 + "※ 명령어 의미" 
                 + " \n "
                 + " ➤ /me 로 등록시는 '개인용' 입니다" 
                 + " \n "
                 + " ➤ /qa 로 등록시는 (본인 + 전체) 가 수신받을수 있습니다";      

            //이미지 + 환영 메시지 
            await oAPP.BOT.sendPhoto(U.chat_id, "https://www.u4ainfo.com/images/common/logo.png", { caption: Lmsg });        
        
        }

        oAPP.T_USER_INFO.push(USER_INFO);

        oAPP.MongoDBO.collection('USER_INFO').insertMany([USER_INFO], {}, (err, res)=>{

                if(err){ return; }

                //환영 메시지 처리 
                lfn_webcomeMsg(USER_INFO);
    
        }); 

    },

    //텔레그램 채널전송 채팅 ID 존재여부 점검후
    //존재하지않으면 몽고 DB 적재 처리
    onCheckAdminCHID:async (T_USER_INFO)=>{

        //텔레그램 채널전송 ID 존재여부 점검 
        var T_USER = T_USER_INFO.filter(e=>e.chat_id === oAPP.isChannel_ID);

        //이미 등록 상태라면 
        if(T_USER.length !== 0){ return; }

        var USER_INFO = {
            "chat_id"   : oAPP.isChannel_ID,      //채팅 ID 
            "first_name": "U4A BOT",              //성
            "last_name" : "U4A 채널 전송 채팅 ID", //이름
           
        };


        oAPP.MongoDBO.collection('USER_INFO').insertMany([USER_INFO], {}, (err, res)=>{
                if(err){  return; }
                oAPP.T_USER_INFO.push(USER_INFO);

        }); 

    },

    //[펑션] - API 권한 접속 키 얻기
    onAuthGet: async()=>{

        return new Promise(function(res, rej) {

            oAPP.MongClinet.connect(oAPP.MongDB_HOST, async function(err, db) {
            
                if (err) { return; }

                var DBO = db.db("U4A_ADMIN");

                DBO.collection("SNS_AUTHORITY").find({}).limit(0).toArray(function(err, T_AUTH) {
                    db.close();
                    if(err){ res({"RETCD":"E", "RTMSG":"몽고 DB 연결 실패"}); return; } //오류
                    if(T_AUTH.length === 0){  res({"RETCD":"E", "RTMSG":"API 권한 Key정보 누락"}); return; }

                    //텔레그램 
                    var T_DATA = T_AUTH.filter(e => e.COMPANY == "TELEGRAM" && e.API_NAME == "BOT" );
                    if(T_DATA.length === 0){ res({"RETCD":"E", "RTMSG":"유투브 Key정보 누락"}); return; }
                    
                    oAPP.TelegramToken = T_DATA[0].AUTH_DATA.TOKEN; 
                    
                    res({"RETCD":"S", "RTMSG":""});
                    
                });

            });

        });

    },

    //[펑션] - 자동 응답 처리 
    onAutoBOT:async (msg)=>{
        debugger;
        //BOT 질문/답변 학습 
        if( await oAPP.BOT_learning(msg)){ return; }

        //BOT 질문에 대한 답변 처리 
        if( await oAPP.BOT_answer(msg)){ return; }

        debugger;

        //여기 프로세스까지 온다는것은 질문에 대한 답변을 못찾음
        await oAPP.BOT.sendMessage(msg.chat.id, "😭 찾으시는 정보가 없어요 😭");

    }

    
};

//Device ready 
document.addEventListener('deviceready', onDeviceReady, false);
async function onDeviceReady() {
    await oAPP.onStart();

}




function fn_onStart(){

    //telegram bot 시작 
    oAPP.onBOTstart();

    var oWin = oAPP.remote.getCurrentWindow();

    //트레이 아이콘 생성 
    oAPP.otray = new oAPP.Tray(oAPP.LOGO_IMG_PATH);
    oAPP.otray.setToolTip("U4A - Telegram BOT 머신");

    oAPP.otray.on("click", (e)=>{ 
            oWin.show();
            oAPP.otray.destroy(); 
             
    });


    //서비스 재시작 ON 처리 알림 메시지 
    if( fn_getCOMPUTERNAME() === "U4ARNDX" ){
        fn_serviceONsendMsg("ON");

    }

    //백그라운드 진입
    oWin.hide();

}


function fn_onStop(){

    
}

//현재 실행 pc명 
function fn_getCOMPUTERNAME(){
    var sName = process.env.COMPUTERNAME.toUpperCase();
    return sName;

}

//서비스 Restat on/off 관리자에게 메시지 전송 
async function fn_serviceONsendMsg(ACTCD){

    var BOT = new oAPP.TelegramBot("5462273470:AAFtKZ14L-EBxyH84KF7tunAYxf_AFVbpTQ", {polling: false});

    //오늘 일자 
    let today = new Date();
    let year = today.getFullYear();   // 년도
    let month = today.getMonth() + 1; // 월
    let date = today.getDate();       // 날짜
    let day = today.getDay();         // 요일

    //문자열로 변경 
    year  = year.toString();
    month = month.toString();
    date  = date.toString();
    date  = date.padStart(2, '0'); // 0붙이기
    day   = day.toString();

    var Ldate = year + "/" + month + "/" + date;

    switch (ACTCD) {
        case "ON":
            //텔레그램에 전송 메시지 구성 - 서비스 ON
            var LsendMSG = "😀 [ Telegram BOT - 서비스 ON ] 😀 \n\n " 
                         + "📅 [ 수행일자 : " + Ldate + "] \n ";
            break;
    
        case "OFF":
            //텔레그램에 전송 메시지 구성 - 서비스 OFF
            var LsendMSG = "🥶 [ Telegram BOT - 서비스 OFF ] 🥶\n\n " 
            + "📅 [ 수행일자 : " + Ldate + "] \n ";    

            break;

    }


    //텔레그램 전송 admin 사용자만 
    await BOT.sendMessage("2142197003", LsendMSG); //홍영선 
    await BOT.sendMessage("5311179178", LsendMSG); //홍성호
    await BOT.sendMessage("2141804045", LsendMSG); //박은섭
    await BOT.sendMessage("498542502",  LsendMSG); //이청윤

}